/* =========================================================
   TENKAI - REGISTER SYSTEM
   Front-End Registration Flow
========================================================= */

"use strict";


/* =========================================================
   STATE
========================================================= */

let currentStep = 0;

let signupMethod = "";

let selectedGender = "";

let selectedAnime = [];

let profileImage = null;


/* =========================================================
   HISTORY STATE
========================================================= */

/*
 * Used to prevent showStep()
 * from creating a new history entry
 * when the user presses the device/browser Back button.
 */

let isHandlingHistory = false;


/* =========================================================
   ELEMENTS
========================================================= */

const form =
    document.getElementById("registerForm");

const steps =
    document.querySelectorAll(".register-step");

const progressSteps =
    document.querySelectorAll(".progress-step");

const registerContent =
    document.querySelector(".register-content");


/* =========================================================
   STEP SYSTEM
========================================================= */

function showStep(stepNumber) {

    if (
        stepNumber < 0 ||
        stepNumber >= steps.length
    ) {
        return;
    }


    currentStep = stepNumber;


    /* -----------------------------------------------------
       Browser History
    ----------------------------------------------------- */

    /*
     * Every normal step change gets its own
     * history entry.
     *
     * The URL itself does NOT change.
     */

    if (!isHandlingHistory) {

        history.pushState(
            {
                registerStep: stepNumber
            },
            "",
            window.location.href
        );

    }


    /* -----------------------------------------------------
       Hide all steps
    ----------------------------------------------------- */

    steps.forEach((step) => {

        step.classList.remove("active");

    });


    /* -----------------------------------------------------
       Show current step
    ----------------------------------------------------- */

    steps[currentStep].classList.add("active");


    /* -----------------------------------------------------
       Update progress
    ----------------------------------------------------- */

    progressSteps.forEach(
        (progress, index) => {

            progress.classList.toggle(
                "active",
                index === currentStep
            );

        }
    );


    /* -----------------------------------------------------
       Scroll content to top
    ----------------------------------------------------- */

    if (registerContent) {

        registerContent.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    }


    /* -----------------------------------------------------
       Update identifier screen
    ----------------------------------------------------- */

    if (currentStep === 4) {

        updateIdentifierScreen();

    }

}


/* =========================================================
   ERROR MESSAGE
========================================================= */

function showError(message) {

    if (
        typeof window.tenkoError ===
        "function"
    ) {

        window.tenkoError(message);

        return;

    }


    console.error(message);

}


/* =========================================================
   SUCCESS MESSAGE
========================================================= */

function showSuccess(message) {

    if (
        typeof window.tenkoSuccess ===
        "function"
    ) {

        window.tenkoSuccess(message);

        return;

    }


    console.log(message);

}


/* =========================================================
   SIGN UP METHOD
========================================================= */

const signupMethodButtons =
    document.querySelectorAll(
        ".signup-method-button"
    );


signupMethodButtons.forEach(
    (button) => {

        button.addEventListener(
            "click",
            () => {

                signupMethod =
                    button.dataset.method;


                if (
                    signupMethod !== "phone" &&
                    signupMethod !== "email"
                ) {

                    showError(
                        "Invalid sign up method."
                    );

                    return;

                }


                updateIdentifierScreen();

                showStep(1);

            }
        );

    }
);


/* =========================================================
   GOOGLE SIGN UP
========================================================= */

const googleSignup =
    document.getElementById(
        "googleSignup"
    );


if (googleSignup) {

    googleSignup.addEventListener(
        "click",
        () => {

            showError(
                "Google Sign Up is not connected yet."
            );

        }
    );

}


/* =========================================================
   FACEBOOK SIGN UP
========================================================= */

const facebookSignup =
    document.getElementById(
        "facebookSignup"
    );


if (facebookSignup) {

    facebookSignup.addEventListener(
        "click",
        () => {

            showError(
                "Facebook Sign Up is not connected yet."
            );

        }
    );

}


/* =========================================================
   NAME
========================================================= */

const nameNext =
    document.getElementById(
        "nameNext"
    );


if (nameNext) {

    nameNext.addEventListener(
        "click",
        () => {

            const firstName =
                document.getElementById(
                    "firstName"
                )?.value.trim();


            const lastName =
                document.getElementById(
                    "lastName"
                )?.value.trim();


            if (!firstName) {

                showError(
                    "Please enter your first name."
                );

                return;

            }


            if (!lastName) {

                showError(
                    "Please enter your last name."
                );

                return;

            }


            showStep(2);

        }
    );

}


/* =========================================================
   BIRTHDAY
========================================================= */

const birthdayNext =
    document.getElementById(
        "birthdayNext"
    );


if (birthdayNext) {

    birthdayNext.addEventListener(
        "click",
        () => {

            const birthday =
                document.getElementById(
                    "birthday"
                )?.value;


            if (!birthday) {

                showError(
                    "Please enter your birthday."
                );

                return;

            }


            showStep(3);

        }
    );

}


/* =========================================================
   GENDER
========================================================= */

const genderOptions =
    document.querySelectorAll(
        ".gender-option"
    );


genderOptions.forEach(
    (button) => {

        button.addEventListener(
            "click",
            () => {

                genderOptions.forEach(
                    (item) => {

                        item.classList.remove(
                            "selected"
                        );

                    }
                );


                button.classList.add(
                    "selected"
                );


                selectedGender =
                    button.dataset.gender;


                setTimeout(
                    () => {

                        showStep(4);

                    },
                    200
                );

            }
        );

    }
);


/* =========================================================
   PHONE / EMAIL
========================================================= */

const identifierTitle =
    document.getElementById(
        "identifierTitle"
    );

const identifierDescription =
    document.getElementById(
        "identifierDescription"
    );

const identifierIcon =
    document.getElementById(
        "identifierIcon"
    );

const identifierInput =
    document.getElementById(
        "identifier"
    );


function updateIdentifierScreen() {

    if (
        !identifierTitle ||
        !identifierDescription ||
        !identifierIcon ||
        !identifierInput
    ) {

        return;

    }


    if (
        signupMethod === "phone"
    ) {

        identifierTitle.textContent =
            "What's your phone number?";


        identifierDescription.textContent =
            "We'll use it to verify your account.";


        identifierInput.placeholder =
            "Enter your phone number";


        identifierInput.type =
            "tel";


        identifierInput.inputMode =
            "tel";


        identifierInput.autocomplete =
            "tel";


        identifierIcon.className =
            "fa-solid fa-phone input-icon";

    }


    else if (
        signupMethod === "email"
    ) {

        identifierTitle.textContent =
            "What's your email?";


        identifierDescription.textContent =
            "We'll use it to verify your account.";


        identifierInput.placeholder =
            "Enter your email";


        identifierInput.type =
            "email";


        identifierInput.inputMode =
            "email";


        identifierInput.autocomplete =
            "email";


        identifierIcon.className =
            "fa-solid fa-envelope input-icon";

    }

}


/* =========================================================
   IDENTIFIER NEXT
========================================================= */

const identifierNext =
    document.getElementById(
        "identifierNext"
    );


if (
    identifierNext &&
    identifierInput
) {

    identifierNext.addEventListener(
        "click",
        () => {

            const value =
                identifierInput.value.trim();


            /* -------------------------------------------------
               Empty
            ------------------------------------------------- */

            if (!value) {

                if (
                    signupMethod === "phone"
                ) {

                    showError(
                        "Please enter your phone number."
                    );

                }

                else {

                    showError(
                        "Please enter your email."
                    );

                }

                return;

            }


            /* -------------------------------------------------
               Email validation
            ------------------------------------------------- */

            if (
                signupMethod === "email"
            ) {

                const emailPattern =
                    /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


                if (
                    !emailPattern.test(value)
                ) {

                    showError(
                        "Please enter a valid email address."
                    );

                    return;

                }

            }


            /* -------------------------------------------------
               Phone validation
            ------------------------------------------------- */

            if (
                signupMethod === "phone"
            ) {

                const phonePattern =
                    /^\+?[0-9\s\-()]{8,20}$/;


                if (
                    !phonePattern.test(value)
                ) {

                    showError(
                        "Please enter a valid phone number."
                    );

                    return;

                }

            }


            showStep(5);

        }
    );

}


/* =========================================================
   VERIFICATION INPUTS
========================================================= */

const verificationInputs =
    document.querySelectorAll(
        ".verification-code"
    );


verificationInputs.forEach(
    (input, index) => {


        input.addEventListener(
            "input",
            () => {

                input.value =
                    input.value.replace(
                        /\D/g,
                        ""
                    );


                if (
                    input.value &&
                    index <
                    verificationInputs.length - 1
                ) {

                    verificationInputs[
                        index + 1
                    ].focus();

                }

            }
        );


        input.addEventListener(
            "keydown",
            (event) => {

                if (
                    event.key === "Backspace" &&
                    !input.value &&
                    index > 0
                ) {

                    verificationInputs[
                        index - 1
                    ].focus();

                }

            }
        );


        input.addEventListener(
            "paste",
            (event) => {

                event.preventDefault();


                const pasted =
                    (
                        event.clipboardData ||
                        window.clipboardData
                    )
                    .getData("text")
                    .replace(/\D/g, "")
                    .slice(
                        0,
                        verificationInputs.length
                    );


                pasted.split("").forEach(
                    (digit, digitIndex) => {

                        if (
                            verificationInputs[
                                digitIndex
                            ]
                        ) {

                            verificationInputs[
                                digitIndex
                            ].value = digit;

                        }

                    }
                );


                const lastIndex =
                    Math.min(
                        pasted.length,
                        verificationInputs.length
                    ) - 1;


                if (lastIndex >= 0) {

                    verificationInputs[
                        lastIndex
                    ].focus();

                }

            }
        );

    }
);


/* =========================================================
   VERIFICATION NEXT
========================================================= */

const verificationNext =
    document.getElementById(
        "verificationNext"
    );


if (verificationNext) {

    verificationNext.addEventListener(
        "click",
        () => {

            let code = "";


            verificationInputs.forEach(
                (input) => {

                    code += input.value;

                }
            );


            if (
                code.length !==
                verificationInputs.length
            ) {

                showError(
                    "Please enter the complete verification code."
                );

                return;

            }


            showSuccess(
                "Verification completed."
            );


            showStep(6);

        }
    );

}


/* =========================================================
   PASSWORD TOGGLE
========================================================= */

const passwordToggle =
    document.getElementById(
        "registerPasswordToggle"
    );

const passwordInput =
    document.getElementById(
        "registerPassword"
    );


if (
    passwordToggle &&
    passwordInput
) {

    passwordToggle.addEventListener(
        "click",
        () => {

            const icon =
                passwordToggle.querySelector(
                    "i"
                );


            const isPassword =
                passwordInput.type ===
                "password";


            passwordInput.type =
                isPassword
                    ? "text"
                    : "password";


            if (icon) {

                icon.classList.toggle(
                    "fa-eye",
                    !isPassword
                );

                icon.classList.toggle(
                    "fa-eye-slash",
                    isPassword
                );

            }


            passwordToggle.setAttribute(
                "aria-label",
                isPassword
                    ? "Hide password"
                    : "Show password"
            );

        }
    );

}


/* =========================================================
   PASSWORD
========================================================= */

const passwordNext =
    document.getElementById(
        "passwordNext"
    );


if (passwordNext) {

    passwordNext.addEventListener(
        "click",
        () => {

            const password =
                document.getElementById(
                    "registerPassword"
                )?.value || "";


            const confirmPassword =
                document.getElementById(
                    "registerPasswordConfirm"
                )?.value || "";


            if (!password) {

                showError(
                    "Please create a password."
                );

                return;

            }


            if (
                password.length < 8
            ) {

                showError(
                    "Your password must be at least 8 characters."
                );

                return;

            }


            if (
                password !==
                confirmPassword
            ) {

                showError(
                    "The passwords don't match."
                );

                return;

            }


            showStep(7);

        }
    );

}


/* =========================================================
   PROFILE PICTURE
========================================================= */

const choosePicture =
    document.getElementById(
        "choosePicture"
    );

const profilePicture =
    document.getElementById(
        "profilePicture"
    );

const profilePreview =
    document.getElementById(
        "profilePreview"
    );

const pictureNext =
    document.getElementById(
        "pictureNext"
    );

const skipPicture =
    document.getElementById(
        "skipPicture"
    );


if (
    choosePicture &&
    profilePicture
) {

    choosePicture.addEventListener(
        "click",
        () => {

            profilePicture.click();

        }
    );

}


if (
    profilePicture &&
    profilePreview
) {

    profilePicture.addEventListener(
        "change",
        () => {

            const file =
                profilePicture.files?.[0];


            if (!file) {

                return;

            }


            if (
                !file.type.startsWith(
                    "image/"
                )
            ) {

                showError(
                    "Please choose an image."
                );

                profilePicture.value = "";

                return;

            }


            /* Limit front-end preview to 5MB */

            if (
                file.size >
                5 * 1024 * 1024
            ) {

                showError(
                    "The image must be smaller than 5MB."
                );

                profilePicture.value = "";

                return;

            }


            profileImage = file;


            const reader =
                new FileReader();


            reader.onload =
                (event) => {

                    const image =
                        profilePreview.querySelector(
                            "img"
                        );


                    if (!image) {

                        return;

                    }


                    image.src =
                        event.target.result;


                    profilePreview.classList.add(
                        "has-image"
                    );


                    if (pictureNext) {

                        pictureNext.style.display =
                            "block";

                    }


                    if (skipPicture) {

                        skipPicture.style.display =
                            "none";

                    }

                };


            reader.readAsDataURL(file);

        }
    );

}


/* =========================================================
   SKIP PROFILE PICTURE
========================================================= */

if (skipPicture) {

    skipPicture.addEventListener(
        "click",
        () => {

            profileImage = null;

            showStep(8);

        }
    );

}


/* =========================================================
   CONTINUE WITH PROFILE PICTURE
========================================================= */

if (pictureNext) {

    pictureNext.addEventListener(
        "click",
        () => {

            if (!profileImage) {

                showError(
                    "Please choose a profile picture first."
                );

                return;

            }


            showStep(8);

        }
    );

}


/* =========================================================
   FAVORITE ANIME
========================================================= */

const animeOptions =
    document.querySelectorAll(
        ".anime-option"
    );


animeOptions.forEach(
    (button) => {

        button.addEventListener(
            "click",
            () => {

                const anime =
                    button.dataset.anime;


                if (!anime) {

                    return;

                }


                button.classList.toggle(
                    "selected"
                );


                if (
                    button.classList.contains(
                        "selected"
                    )
                ) {

                    if (
                        !selectedAnime.includes(
                            anime
                        )
                    ) {

                        selectedAnime.push(
                            anime
                        );

                    }

                }

                else {

                    selectedAnime =
                        selectedAnime.filter(
                            (item) =>
                                item !== anime
                        );

                }

            }
        );

    }
);


/* =========================================================
   ANIME NEXT
========================================================= */

const animeNext =
    document.getElementById(
        "animeNext"
    );


if (animeNext) {

    animeNext.addEventListener(
        "click",
        () => {

            if (
                selectedAnime.length === 0
            ) {

                showError(
                    "Choose at least one favorite anime."
                );

                return;

            }


            showStep(9);

        }
    );

}


/* =========================================================
   FINISH REGISTRATION
========================================================= */

const finishRegistration =
    document.getElementById(
        "finishRegistration"
    );


if (finishRegistration) {

    finishRegistration.addEventListener(
        "click",
        () => {

            const firstName =
                document.getElementById(
                    "firstName"
                )?.value.trim();


            const lastName =
                document.getElementById(
                    "lastName"
                )?.value.trim();


            const birthday =
                document.getElementById(
                    "birthday"
                )?.value;


            const identifier =
                identifierInput?.value.trim();


            /* -------------------------------------------------
               Final validation
            ------------------------------------------------- */

            if (!signupMethod) {

                showError(
                    "Please choose a sign up method."
                );

                showStep(0);

                return;

            }


            if (!firstName || !lastName) {

                showError(
                    "Please complete your name."
                );

                showStep(1);

                return;

            }


            if (!birthday) {

                showError(
                    "Please enter your birthday."
                );

                showStep(2);

                return;

            }


            if (!selectedGender) {

                showError(
                    "Please select your gender."
                );

                showStep(3);

                return;

            }


            if (!identifier) {

                showError(
                    "Please enter your phone number or email."
                );

                showStep(4);

                return;

            }


            if (!selectedAnime.length) {

                showError(
                    "Choose at least one favorite anime."
                );

                showStep(8);

                return;

            }


            /* -------------------------------------------------
               Temporary registration object
            ------------------------------------------------- */

            const registrationData = {

                signupMethod,

                firstName,

                lastName,

                birthday,

                gender: selectedGender,

                identifier,

                favoriteAnime: [
                    ...selectedAnime
                ],

                profileImage: profileImage
                    ? {
                        name:
                            profileImage.name,

                        type:
                            profileImage.type,

                        size:
                            profileImage.size
                    }
                    : null

            };


            /*
             * Temporary only.
             *
             * Later this object will be sent
             * to Firebase Authentication,
             * Firestore and Storage.
             */

            console.log(
                "TENKAI Registration:",
                registrationData
            );


            showSuccess(
                "Welcome to TENKAI!"
            );


            setTimeout(
                () => {

                    window.location.href =
                        "../home/home.html";

                },
                1200
            );

        }
    );

}


/* =========================================================
   FORM PROTECTION
========================================================= */

if (form) {

    form.addEventListener(
        "submit",
        (event) => {

            event.preventDefault();

        }
    );

}


/* =========================================================
   MOBILE / BROWSER BACK BUTTON
========================================================= */

window.addEventListener(
    "popstate",
    (event) => {

        /* -------------------------------------------------
           Check if the history entry belongs
           to the TENKAI registration flow.
        ------------------------------------------------- */

        if (
            event.state &&
            typeof event.state.registerStep ===
            "number"
        ) {

            isHandlingHistory = true;


            showStep(
                event.state.registerStep
            );


            isHandlingHistory = false;

        }

    }
);


/* =========================================================
   INITIALIZE HISTORY
========================================================= */

/*
 * The current page becomes Step 0.
 *
 * replaceState() does NOT create a new history entry.
 * It only attaches our registration state
 * to the current page.
 */

history.replaceState(
    {
        registerStep: 0
    },
    "",
    window.location.href
);


/* =========================================================
   INITIALIZE REGISTER
========================================================= */

/*
 * false here is achieved through
 * isHandlingHistory so Step 0 does not
 * create an extra history entry.
 */

isHandlingHistory = true;

showStep(0);

isHandlingHistory = false;


console.log(
    "TENKAI Register System is running."
);