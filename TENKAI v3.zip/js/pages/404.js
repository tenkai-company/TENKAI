/* =========================================================
   TENKAI — 404 PAGE
========================================================= */

"use strict";


/* =========================================================
   BACK BUTTON
========================================================= */

const backButton =
    document.getElementById("backButton");


if (backButton) {

    backButton.addEventListener(
        "click",
        () => {

            /*
             * If the browser has a previous page,
             * return to it.
             */

            if (
                window.history.length > 1
            ) {

                window.history.back();

                return;

            }


            /*
             * If there is no usable history,
             * return to TENKAI home.
             */

            window.location.href =
                "index.html";

        }
    );

}


/* =========================================================
   KEYBOARD SUPPORT
========================================================= */

document.addEventListener(
    "keydown",
    (event) => {

        if (
            event.key === "Escape" &&
            backButton
        ) {

            backButton.click();

        }

    }
);