/*
 * TENKAI — Home / Feed
 * Phase 2
 * Front-end only — no Firebase
 */

(() => {
    "use strict";


    /* ================================
       MOCK POSTS
    ================================= */

    const TENKAI_POSTS = [
        {
            id: 1,
            username: "Yuki",
            handle: "@yuki",
            time: "2h",
            avatar: "../../assets/images/tenko.png",
            text: "Just finished another episode. TENKAI is getting better every day.",
            anime: "Attack on Titan",
            likes: 120,
            comments: 24,
            liked: false,
            saved: false,
            following: false,
            spoiler: false
        },

        {
            id: 2,
            username: "Ren",
            handle: "@ren_01",
            time: "4h",
            avatar: "../../assets/images/tenko.png",
            text: "What anime are you watching this week?",
            anime: "One Piece",
            likes: 86,
            comments: 13,
            liked: false,
            saved: false,
            following: false,
            spoiler: false
        },

        {
            id: 3,
            username: "Mika",
            handle: "@mika",
            time: "6h",
            avatar: "../../assets/images/tenko.png",
            text: "This post contains a spoiler.",
            anime: "Demon Slayer",
            likes: 42,
            comments: 8,
            liked: false,
            saved: false,
            following: false,
            spoiler: true
        }
    ];


    let posts = TENKAI_POSTS.map(post => ({
        ...post
    }));


    /* ================================
       DOM ELEMENTS
    ================================= */

    const postsContainer =
        document.querySelector("#posts");

    const menuButton =
        document.querySelector("#menuButton");

    const sidebar =
        document.querySelector("#sidebar");

    const sidebarOverlay =
        document.querySelector("#sidebarOverlay");

    const searchButton =
        document.querySelector("#searchButton");

    const mobileSearch =
        document.querySelector("#mobileSearch");

    const searchInput =
        document.querySelector("#searchInput");

    const clearSearch =
        document.querySelector("#clearSearch");

    const notificationButton =
        document.querySelector("#notificationButton");

    const createPostButton =
        document.querySelector("#createPostButton");

    const createMediaButton =
        document.querySelector("#createMediaButton");

    const fabButton =
        document.querySelector("#fabButton");

    const bottomCreateButton =
        document.querySelector("#bottomCreateButton");

    const refreshFeed =
        document.querySelector("#refreshFeed");

    const feedStatus =
        document.querySelector("#feedStatus");

    const trendingButton =
        document.querySelector("#trendingButton");


    /* ================================
       TENKO
    ================================= */

    function notify(message, type = "info") {

        if (
            typeof window.Tenko === "object" &&
            window.Tenko !== null
        ) {

            if (
                type === "success" &&
                typeof window.Tenko.success === "function"
            ) {
                window.Tenko.success(message);
                return;
            }


            if (
                type === "error" &&
                typeof window.Tenko.error === "function"
            ) {
                window.Tenko.error(message);
                return;
            }


            if (
                typeof window.Tenko.info === "function"
            ) {
                window.Tenko.info(message);
                return;
            }
        }


        if (
            typeof window.tenkoMessage === "function"
        ) {
            window.tenkoMessage(
                message,
                type
            );
        }
    }


    /* ================================
       HTML ESCAPE
    ================================= */

    function escapeHTML(value) {

        return String(value)
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    }


    /* ================================
       POST TEMPLATE
    ================================= */

    function createPostHTML(post) {

        const likedClass =
            post.liked
                ? "is-liked"
                : "";

        const savedClass =
            post.saved
                ? "is-saved"
                : "";

        const followText =
            post.following
                ? "Following"
                : "Follow";


        let contentHTML;


        if (post.spoiler) {

            contentHTML = `
                <div
                    class="post-spoiler"
                    data-spoiler="${post.id}"
                >

                    <div class="post-spoiler__icon">
                        ⚠
                    </div>

                    <strong>
                        Spoiler warning
                    </strong>

                    <span>
                        This post contains a spoiler.
                    </span>

                    <button
                        type="button"
                        data-action="reveal"
                        data-id="${post.id}"
                    >
                        Show Spoiler
                    </button>

                </div>
            `;

        } else {

            contentHTML = `
                <div class="post-content">

                    <p>
                        ${escapeHTML(post.text)}
                    </p>

                    <span class="anime-tag">
                        ${escapeHTML(post.anime)}
                    </span>

                </div>
            `;
        }


        return `
            <article
                class="post-card"
                data-post-id="${post.id}"
            >

                <header class="post-header">

                    <img
                        class="post-avatar"
                        src="${post.avatar}"
                        alt=""
                    >


                    <div class="post-user">

                        <div class="post-user__top">

                            <strong>
                                ${escapeHTML(post.username)}
                            </strong>


                            <button
                                class="follow-button"
                                type="button"
                                data-action="follow"
                                data-id="${post.id}"
                            >
                                ${followText}
                            </button>

                        </div>


                        <span>
                            ${escapeHTML(post.handle)}
                            ·
                            ${escapeHTML(post.time)}
                        </span>

                    </div>


                    <button
                        class="post-more"
                        type="button"
                        aria-label="More options"
                    >
                        •••
                    </button>

                </header>


                ${contentHTML}


                <div class="post-stats">

                    <span>
                        ${post.likes} likes
                    </span>

                    <span>
                        ${post.comments} comments
                    </span>

                </div>


                <div class="post-actions">

                    <button
                        class="post-action ${likedClass}"
                        type="button"
                        data-action="like"
                        data-id="${post.id}"
                    >

                        <span aria-hidden="true">
                            ♡
                        </span>

                        <span>
                            Like
                        </span>

                    </button>


                    <button
                        class="post-action"
                        type="button"
                        data-action="comment"
                        data-id="${post.id}"
                    >

                        <span aria-hidden="true">
                            💬
                        </span>

                        <span>
                            Comment
                        </span>

                    </button>


                    <button
                        class="post-action ${savedClass}"
                        type="button"
                        data-action="save"
                        data-id="${post.id}"
                    >

                        <span aria-hidden="true">
                            🔖
                        </span>

                        <span>
                            Save
                        </span>

                    </button>


                    <button
                        class="post-action"
                        type="button"
                        data-action="share"
                        data-id="${post.id}"
                    >

                        <span aria-hidden="true">
                            ↗
                        </span>

                        <span>
                            Share
                        </span>

                    </button>

                </div>

            </article>
        `;
    }


    /* ================================
       RENDER FEED
    ================================= */

    function renderPosts() {

        if (!postsContainer) {

            console.warn(
                "TENKAI: #posts was not found."
            );

            return;
        }


        postsContainer.innerHTML =
            posts
                .map(createPostHTML)
                .join("");
    }


    /* ================================
       GET POST
    ================================= */

    function getPost(id) {

        return posts.find(
            post =>
                post.id === Number(id)
        );
    }


    /* ================================
       POST ACTIONS
    ================================= */

    function handlePostAction(event) {

        const button =
            event.target.closest(
                "[data-action]"
            );


        if (!button) {
            return;
        }


        const action =
            button.dataset.action;


        const post =
            getPost(button.dataset.id);


        if (!post) {
            return;
        }


        /* LIKE */

        if (action === "like") {

            post.liked =
                !post.liked;


            post.likes +=
                post.liked
                    ? 1
                    : -1;


            renderPosts();


            notify(
                post.liked
                    ? "Post liked ❤️"
                    : "Like removed",
                "success"
            );
        }


        /* SAVE */

        if (action === "save") {

            post.saved =
                !post.saved;


            renderPosts();


            notify(
                post.saved
                    ? "Post saved 🔖"
                    : "Post removed from saved posts",
                "success"
            );
        }


        /* FOLLOW */

        if (action === "follow") {

            post.following =
                !post.following;


            renderPosts();


            notify(
                post.following
                    ? `You are now following ${post.username}`
                    : `You unfollowed ${post.username}`,
                "success"
            );
        }


        /* COMMENT */

        if (action === "comment") {

            notify(
                "Comments will be available soon.",
                "info"
            );
        }


        /* SHARE */

        if (action === "share") {

            notify(
                "Share system will be connected later.",
                "info"
            );
        }


        /* REVEAL SPOILER */

        if (action === "reveal") {

            post.spoiler = false;

            renderPosts();

            notify(
                "Spoiler revealed.",
                "info"
            );
        }
    }


    /* ================================
       SIDEBAR
    ================================= */

    function openSidebar() {

        if (!sidebar) {
            return;
        }


        sidebar.classList.add(
            "is-open"
        );


        if (sidebarOverlay) {

            sidebarOverlay.hidden = false;

            requestAnimationFrame(() => {

                sidebarOverlay.classList.add(
                    "is-visible"
                );
            });
        }


        if (menuButton) {

            menuButton.setAttribute(
                "aria-expanded",
                "true"
            );
        }
    }


    function closeSidebar() {

        if (!sidebar) {
            return;
        }


        sidebar.classList.remove(
            "is-open"
        );


        if (sidebarOverlay) {

            sidebarOverlay.classList.remove(
                "is-visible"
            );

            setTimeout(() => {

                if (
                    !sidebar.classList.contains(
                        "is-open"
                    )
                ) {
                    sidebarOverlay.hidden = true;
                }

            }, 200);
        }


        if (menuButton) {

            menuButton.setAttribute(
                "aria-expanded",
                "false"
            );
        }
    }


    function setupSidebar() {

        if (menuButton) {

            menuButton.addEventListener(
                "click",
                () => {

                    if (
                        sidebar &&
                        sidebar.classList.contains(
                            "is-open"
                        )
                    ) {
                        closeSidebar();
                    } else {
                        openSidebar();
                    }
                }
            );
        }


        if (sidebarOverlay) {

            sidebarOverlay.addEventListener(
                "click",
                closeSidebar
            );
        }
    }


    /* ================================
       MOBILE SEARCH
    ================================= */

    function setupSearch() {

        if (searchButton) {

            searchButton.addEventListener(
                "click",
                () => {

                    if (!mobileSearch) {
                        return;
                    }


                    mobileSearch.hidden =
                        !mobileSearch.hidden;


                    if (!mobileSearch.hidden) {

                        searchInput?.focus();
                    }
                }
            );
        }


        if (clearSearch) {

            clearSearch.addEventListener(
                "click",
                () => {

                    if (searchInput) {

                        searchInput.value = "";

                        searchInput.focus();
                    }
                }
            );
        }


        if (searchInput) {

            searchInput.addEventListener(
                "keydown",
                event => {

                    if (
                        event.key !== "Enter"
                    ) {
                        return;
                    }


                    const query =
                        searchInput.value.trim();


                    if (!query) {

                        notify(
                            "Write something to search.",
                            "info"
                        );

                        return;
                    }


                    notify(
                        `Searching for "${query}"...`,
                        "info"
                    );
                }
            );
        }
    }


    /* ================================
       CREATE POST
    ================================= */

    function handleCreatePost() {

        notify(
            "Create Post will be available next.",
            "info"
        );
    }


    function setupCreatePost() {

        [
            createPostButton,
            createMediaButton,
            fabButton,
            bottomCreateButton
        ].forEach(button => {

            if (button) {

                button.addEventListener(
                    "click",
                    handleCreatePost
                );
            }
        });
    }


    /* ================================
       NOTIFICATIONS
    ================================= */

    function setupNotifications() {

        if (!notificationButton) {
            return;
        }


        notificationButton.addEventListener(
            "click",
            () => {

                notify(
                    "Notifications will be available soon.",
                    "info"
                );
            }
        );
    }


    /* ================================
       ANIME SHORTCUTS
    ================================= */

    function setupAnimeShortcuts() {

        const buttons =
            document.querySelectorAll(
                "[data-anime]"
            );


        buttons.forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    const anime =
                        button.dataset.anime;


                    if (!anime) {
                        return;
                    }


                    notify(
                        `Showing posts about ${anime}.`,
                        "info"
                    );
                }
            );
        });
    }


    /* ================================
       FOLLOW SUGGESTIONS
    ================================= */

    function setupFollowButtons() {

        const buttons =
            document.querySelectorAll(
                "[data-follow]"
            );


        buttons.forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    const username =
                        button.dataset.follow;


                    const following =
                        button.dataset.following === "true";


                    button.dataset.following =
                        following
                            ? "false"
                            : "true";


                    button.textContent =
                        following
                            ? "Follow"
                            : "Following";


                    notify(
                        following
                            ? `You unfollowed ${username}.`
                            : `You are now following ${username}.`,
                        "success"
                    );
                }
            );
        });
    }


    /* ================================
       REFRESH FEED
    ================================= */

    function setupRefresh() {

        if (!refreshFeed) {
            return;
        }


        refreshFeed.addEventListener(
            "click",
            () => {

                posts =
                    TENKAI_POSTS.map(
                        post => ({
                            ...post
                        })
                    );


                renderPosts();


                if (feedStatus) {

                    feedStatus.textContent =
                        "Updated just now";
                }


                notify(
                    "Feed refreshed.",
                    "success"
                );
            }
        );
    }


    /* ================================
       TRENDING
    ================================= */

    function setupTrending() {

        if (!trendingButton) {
            return;
        }


        trendingButton.addEventListener(
            "click",
            () => {

                notify(
                    "Trending page will be available next.",
                    "info"
                );
            }
        );
    }


    /* ================================
       GLOBAL CLICK HANDLER
    ================================= */

    function setupPostActions() {

        document.addEventListener(
            "click",
            handlePostAction
        );
    }


    /* ================================
       INITIALIZE
    ================================= */

    function init() {

        renderPosts();

        setupSidebar();

        setupSearch();

        setupCreatePost();

        setupNotifications();

        setupAnimeShortcuts();

        setupFollowButtons();

        setupRefresh();

        setupTrending();

        setupPostActions();


        console.log(
            "TENKAI Home initialized successfully."
        );
    }


    /* ================================
       DOM READY
    ================================= */

    if (
        document.readyState === "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            init
        );

    } else {

        init();
    }

})();
     