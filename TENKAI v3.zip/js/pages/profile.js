/* =========================================================
   TENKAI — PROFILE
========================================================= */

"use strict";


document.addEventListener(
    "DOMContentLoaded",
    () => {


        /* =====================================================
           PROFILE STATE
        ====================================================== */

        const profileState = {

            name: "Yuki",

            username: "@yuki",

            bio:
                "Anime enthusiast • TENKAI member",

            posts: 0,

            following: 0,

            followers: 0,

            activeTab: "posts"

        };


        /* =====================================================
           ELEMENTS
        ====================================================== */

        const elements = {

            menuButton:
                document.getElementById(
                    "menuButton"
                ),

            sidebar:
                document.getElementById(
                    "sidebar"
                ),

            sidebarOverlay:
                document.getElementById(
                    "sidebarOverlay"
                ),


            searchButton:
                document.getElementById(
                    "searchButton"
                ),

            notificationButton:
                document.getElementById(
                    "notificationButton"
                ),


            profileName:
                document.getElementById(
                    "profileName"
                ),

            profileUsername:
                document.getElementById(
                    "profileUsername"
                ),

            profileBio:
                document.getElementById(
                    "profileBio"
                ),

            profileAvatar:
                document.getElementById(
                    "profileAvatar"
                ),


            postsCount:
                document.getElementById(
                    "postsCount"
                ),

            followingCount:
                document.getElementById(
                    "followingCount"
                ),

            followersCount:
                document.getElementById(
                    "followersCount"
                ),


            editProfileButton:
                document.getElementById(
                    "editProfileButton"
                ),

            avatarEditButton:
                document.getElementById(
                    "avatarEditButton"
                ),

            coverEditButton:
                document.getElementById(
                    "coverEditButton"
                ),

            createPostButton:
                document.getElementById(
                    "createPostButton"
                ),


            profileTabs:
                document.querySelectorAll(
                    ".profile-tab"
                ),

            profileStatButtons:
                document.querySelectorAll(
                    ".profile-stats [data-profile-tab]"
                ),


            emptyTitle:
                document.getElementById(
                    "emptyTitle"
                ),

            emptyText:
                document.getElementById(
                    "emptyText"
                )

        };


        /* =====================================================
           INITIALIZATION
        ====================================================== */

        function init() {

            renderProfile();

            setupSidebar();

            setupNavigation();

            setupProfileTabs();

            setupProfileActions();

            setupCreatePost();

            console.log(
                "TENKAI Profile initialized."
            );

        }


        /* =====================================================
           RENDER PROFILE
        ====================================================== */

        function renderProfile() {

            if (elements.profileName) {

                elements.profileName.textContent =
                    profileState.name;
            }


            if (elements.profileUsername) {

                elements.profileUsername.textContent =
                    profileState.username;
            }


            if (elements.profileBio) {

                elements.profileBio.textContent =
                    profileState.bio;
            }


            if (elements.profileAvatar) {

                elements.profileAvatar.textContent =
                    getAvatarLetter(
                        profileState.name
                    );
            }


            if (elements.postsCount) {

                elements.postsCount.textContent =
                    formatNumber(
                        profileState.posts
                    );
            }


            if (elements.followingCount) {

                elements.followingCount.textContent =
                    formatNumber(
                        profileState.following
                    );
            }


            if (elements.followersCount) {

                elements.followersCount.textContent =
                    formatNumber(
                        profileState.followers
                    );
            }


            renderActiveTab();

        }


        /* =====================================================
           AVATAR LETTER
        ====================================================== */

        function getAvatarLetter(name) {

            if (
                !name ||
                typeof name !== "string"
            ) {

                return "Y";
            }


            return name
                .trim()
                .charAt(0)
                .toUpperCase();

        }


        /* =====================================================
           NUMBER FORMAT
        ====================================================== */

        function formatNumber(value) {

            const number =
                Number(value);


            if (!Number.isFinite(number)) {

                return "0";
            }


            if (number >= 1000000) {

                return `${(
                    number / 1000000
                ).toFixed(1)}M`;
            }


            if (number >= 1000) {

                return `${(
                    number / 1000
                ).toFixed(1)}K`;
            }


            return String(number);

        }


        /* =====================================================
           SIDEBAR
        ====================================================== */

        function setupSidebar() {

            if (
                !elements.menuButton ||
                !elements.sidebar
            ) {

                return;
            }


            elements.menuButton.addEventListener(
                "click",
                toggleSidebar
            );


            if (elements.sidebarOverlay) {

                elements.sidebarOverlay.addEventListener(
                    "click",
                    closeSidebar
                );

            }


            document.addEventListener(
                "keydown",
                event => {

                    if (
                        event.key ===
                        "Escape"
                    ) {

                        closeSidebar();
                    }

                }
            );

        }


        function toggleSidebar() {

            const isOpen =
                elements.sidebar.classList.contains(
                    "open"
                );


            if (isOpen) {

                closeSidebar();

            } else {

                openSidebar();

            }

        }


        function openSidebar() {

            if (!elements.sidebar) {
                return;
            }


            elements.sidebar.classList.add(
                "open"
            );


            if (elements.sidebarOverlay) {

                elements.sidebarOverlay.hidden =
                    false;
            }


            if (elements.menuButton) {

                elements.menuButton.setAttribute(
                    "aria-expanded",
                    "true"
                );
            }


            document.body.classList.add(
                "sidebar-open"
            );

        }


        function closeSidebar() {

            if (!elements.sidebar) {
                return;
            }


            elements.sidebar.classList.remove(
                "open"
            );


            if (elements.sidebarOverlay) {

                elements.sidebarOverlay.hidden =
                    true;
            }


            if (elements.menuButton) {

                elements.menuButton.setAttribute(
                    "aria-expanded",
                    "false"
                );
            }


            document.body.classList.remove(
                "sidebar-open"
            );

        }


        /* =====================================================
           NAVIGATION
        ====================================================== */

        function setupNavigation() {


            /*
                Search button
            */

            if (elements.searchButton) {

                elements.searchButton.addEventListener(
                    "click",
                    () => {

                        showComingSoon(
                            "Search will be available soon."
                        );

                    }
                );

            }


            /*
                Notification button
            */

            if (
                elements.notificationButton
            ) {

                elements.notificationButton.addEventListener(
                    "click",
                    () => {

                        window.location.href =
                            "../notification/notification.html";

                    }
                );

            }


            /*
                Close sidebar after navigating
            */

            if (elements.sidebar) {

                elements.sidebar
                    .querySelectorAll(
                        "a.nav-item"
                    )
                    .forEach(link => {

                        link.addEventListener(
                            "click",
                            () => {

                                closeSidebar();

                            }
                        );

                    });

            }

        }


        /* =====================================================
           PROFILE TABS
        ====================================================== */

        function setupProfileTabs() {


            elements.profileStatButtons.forEach(
                button => {

                    button.addEventListener(
                        "click",
                        () => {

                            const tab =
                                button.dataset
                                    .profileTab;


                            if (!tab) {
                                return;
                            }


                            setActiveTab(
                                tab
                            );

                        }
                    );

                }
            );


            elements.profileTabs.forEach(
                tabButton => {

                    tabButton.addEventListener(
                        "click",
                        () => {

                            const tab =
                                tabButton.dataset
                                    .profileTab;


                            if (!tab) {
                                return;
                            }


                            setActiveTab(
                                tab
                            );

                        }
                    );

                }
            );

        }


        function setActiveTab(tab) {

            const validTabs = [

                "posts",

                "media",

                "likes",

                "following",

                "followers"

            ];


            if (
                !validTabs.includes(tab)
            ) {

                return;
            }


            profileState.activeTab =
                tab;


            renderActiveTab();

        }


        function renderActiveTab() {


            elements.profileTabs.forEach(
                tabButton => {

                    const isActive =
                        tabButton.dataset
                            .profileTab ===
                        profileState.activeTab;


                    tabButton.classList.toggle(
                        "active",
                        isActive
                    );

                }
            );


            switch (
                profileState.activeTab
            ) {


                case "media":

                    updateEmptyState(
                        "No media yet",
                        "Photos and videos you share will appear here."
                    );

                    break;


                case "likes":

                    updateEmptyState(
                        "No liked posts",
                        "Posts you like will appear here."
                    );

                    break;


                case "following":

                    updateEmptyState(
                        "No following yet",
                        "Accounts you follow will appear here."
                    );

                    break;


                case "followers":

                    updateEmptyState(
                        "No followers yet",
                        "People who follow you will appear here."
                    );

                    break;


                case "posts":

                default:

                    updateEmptyState(
                        "No posts yet",
                        "Your posts will appear here."
                    );

                    break;

            }

        }


        function updateEmptyState(
            title,
            text
        ) {

            if (elements.emptyTitle) {

                elements.emptyTitle.textContent =
                    title;
            }


            if (elements.emptyText) {

                elements.emptyText.textContent =
                    text;
            }

        }


        /* =====================================================
           PROFILE ACTIONS
        ====================================================== */

        function setupProfileActions() {


            if (
                elements.editProfileButton
            ) {

                elements.editProfileButton.addEventListener(
                    "click",
                    () => {

                        showComingSoon(
                            "Profile editing will be connected later."
                        );

                    }
                );

            }


            if (
                elements.avatarEditButton
            ) {

                elements.avatarEditButton.addEventListener(
                    "click",
                    () => {

                        showComingSoon(
                            "Profile picture upload will be connected later."
                        );

                    }
                );

            }


            if (
                elements.coverEditButton
            ) {

                elements.coverEditButton.addEventListener(
                    "click",
                    () => {

                        showComingSoon(
                            "Cover editing will be connected later."
                        );

                    }
                );

            }

        }


        /* =====================================================
           CREATE POST
        ====================================================== */

        function setupCreatePost() {

            if (!elements.createPostButton) {
                return;
            }


            elements.createPostButton.addEventListener(
                "click",
                () => {

                    showComingSoon(
                        "Create Post will be available next."
                    );

                }
            );

        }


        /* =====================================================
           TENKAI FEEDBACK
        ====================================================== */

        function showComingSoon(message) {


            if (
                typeof window.Tenko !==
                    "undefined" &&

                typeof window.Tenko.toast ===
                    "function"
            ) {

                window.Tenko.toast(
                    message
                );

                return;
            }


            if (
                typeof window.showToast ===
                    "function"
            ) {

                window.showToast(
                    message
                );

                return;
            }


            console.info(
                `[TENKAI] ${message}`
            );

        }


        /* =====================================================
           START
        ====================================================== */

        init();

    }
);