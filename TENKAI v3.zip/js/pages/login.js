"use strict";


document.addEventListener(
    "DOMContentLoaded",
    () => {


        /* =====================================================
           ELEMENTS
        ====================================================== */

        const loginForm =
            document.getElementById(
                "loginForm"
            );


        const identifierInput =
            document.getElementById(
                "loginIdentifier"
            );


        const passwordInput =
            document.getElementById(
                "loginPassword"
            );


        const passwordToggle =
            document.getElementById(
                "passwordToggle"
            );


        /* =====================================================
           PASSWORD SHOW / HIDE
        ====================================================== */

        if (
            passwordToggle &&
            passwordInput
        ) {

            passwordToggle.addEventListener(
                "click",
                () => {


                    const icon =
                        passwordToggle.querySelector(
                            "i"
                        );


                    const isPassword =
                        passwordInput.type ===
                        "password";


                    if (isPassword) {

                        passwordInput.type =
                            "text";


                        if (icon) {

                            icon.classList.remove(
                                "fa-eye"
                            );

                            icon.classList.add(
                                "fa-eye-slash"
                            );

                        }


                        passwordToggle.setAttribute(
                            "aria-label",
                            "Hide password"
                        );

                    }


                    else {

                        passwordInput.type =
                            "password";


                        if (icon) {

                            icon.classList.remove(
                                "fa-eye-slash"
                            );

                            icon.classList.add(
                                "fa-eye"
                            );

                        }


                        passwordToggle.setAttribute(
                            "aria-label",
                            "Show password"
                        );

                    }

                }
            );

        }


        /* =====================================================
           LOGIN FORM
        ====================================================== */

        if (loginForm) {

            loginForm.addEventListener(
                "submit",
                (event) => {


                    /*
                        منع الـHTML form
                        من إعادة تحميل الصفحة.
                    */

                    event.preventDefault();


                    /* IDENTIFIER */

                    const identifier =
                        identifierInput
                            ?.value
                            .trim();


                    /* PASSWORD */

                    /*
                        لا نستخدم trim()
                        مع الباسورد.
                    */

                    const password =
                        passwordInput
                            ?.value;


                    /* =================================================
                       IDENTIFIER CHECK
                    ================================================== */

                    if (!identifier) {

                        window.tenkoWarning(
                            "اكتب الإيميل أو رقم الهاتف الأول."
                        );

                        identifierInput?.focus();

                        return;

                    }


                    /* =================================================
                       PASSWORD CHECK
                    ================================================== */

                    if (!password) {

                        window.tenkoWarning(
                            "الباسورد مش موجود. اكتب الباسورد الأول."
                        );

                        passwordInput?.focus();

                        return;

                    }


                    /* =================================================
                       TEMPORARY LOGIN
                    ================================================== */

                    window.tenkoInfo(
                        "جاري تسجيل الدخول..."
                    );


                    /*
                        Firebase Authentication
                        سيتم تركيبه لاحقاً.
                    */

                }
            );

        }


        /* =====================================================
           FACEBOOK
        ====================================================== */

        const facebookButton =
            document.getElementById(
                "facebookLogin"
            );


        if (facebookButton) {

            facebookButton.addEventListener(
                "click",
                (event) => {

                    event.preventDefault();


                    window.tenkoInfo(
                        "تسجيل الدخول باستخدام Facebook هيتم تفعيله قريبًا."
                    );

                }
            );

        }


        /* =====================================================
           GOOGLE
        ====================================================== */

        const googleButton =
            document.getElementById(
                "googleLogin"
            );


        if (googleButton) {

            googleButton.addEventListener(
                "click",
                (event) => {

                    event.preventDefault();


                    window.tenkoInfo(
                        "تسجيل الدخول باستخدام Google هيتم تفعيله قريبًا."
                    );

                }
            );

        }

    }
);