/* =========================================================
   TENKAI — NOTIFICATIONS
   Front-end only
   Firebase will be connected later
========================================================= */

"use strict";


/* =========================================================
   MOCK DATA
========================================================= */

const notifications = [

    {
        id: 1,
        type: "likes",
        user: "Mika",
        username: "@mika",
        avatar: "M",
        message: "liked your post.",
        time: "2 min ago",
        unread: true
    },

    {
        id: 2,
        type: "comments",
        user: "Ren",
        username: "@ren_01",
        avatar: "R",
        message: "commented on your post.",
        time: "14 min ago",
        unread: true
    },

    {
        id: 3,
        type: "anime",
        user: "Akira",
        username: "@akira",
        avatar: "A",
        message:
            'posted about <span class="anime-name">Jujutsu Kaisen</span>.',
        time: "32 min ago",
        unread: true
    },

    {
        id: 4,
        type: "follows",
        user: "Sora",
        username: "@sora",
        avatar: "S",
        message: "started following you.",
        time: "1 hour ago",
        unread: false
    },

    {
        id: 5,
        type: "likes",
        user: "Yuna",
        username: "@yuna",
        avatar: "Y",
        message: "liked your post.",
        time: "2 hours ago",
        unread: false
    },

    {
        id: 6,
        type: "anime",
        user: "Kai",
        username: "@kai",
        avatar: "K",
        message:
            'mentioned <span class="anime-name">Attack on Titan</span> in a discussion.',
        time: "4 hours ago",
        unread: false
    },

    {
        id: 7,
        type: "comments",
        user: "Momo",
        username: "@momo",
        avatar: "M",
        message: "replied to your comment.",
        time: "Yesterday",
        unread: false
    }

];


/* =========================================================
   DOM
========================================================= */

const notificationList =
    document.getElementById("notificationList");

const emptyState =
    document.getElementById("emptyState");

const markAllButton =
    document.getElementById("markAllButton");

const sidebarBadge =
    document.getElementById("sidebarBadge");

const notificationDot =
    document.getElementById("notificationDot");

const menuButton =
    document.getElementById("menuButton");

const sidebar =
    document.getElementById("sidebar");

const sidebarOverlay =
    document.getElementById("sidebarOverlay");

const notificationButton =
    document.getElementById("notificationButton");

const bottomCreateButton =
    document.getElementById("bottomCreateButton");

const filterButtons =
    document.querySelectorAll(".filter-button");


/* =========================================================
   ICONS
========================================================= */

const notificationIcons = {

    likes: `
        <svg viewBox="0 0 24 24" aria-hidden="true">
            <path d="M20.8 8.7c0 5.5-8.8 10.3-8.8 10.3S3.2 14.2 3.2 8.7A4.7 4.7 0 0 1 12 6.1a4.7 4.7 0 0 1 8.8 2.6z"></path>
        </svg>
    `,

    comments: `
        <svg viewBox="0 0 24 24" aria-hidden="true">
            <path d="M4 5h16v11H8l-4 4z"></path>
        </svg>
    `,

    follows: `
        <svg viewBox="0 0 24 24" aria-hidden="true">
            <circle cx="9" cy="8" r="3"></circle>
            <path d="M3.5 19c.6-3 2.5-4.5 5.5-4.5"></path>
            <path d="M17 11v6M14 14h6"></path>
        </svg>
    `,

    anime: `
        <svg viewBox="0 0 24 24" aria-hidden="true">
            <path d="M4 5h16v14H4z"></path>
            <path d="m8 9 3 3-3 3M13 15h3"></path>
        </svg>
    `

};


/* =========================================================
   STATE
========================================================= */

let activeFilter = "all";


/* =========================================================
   TENKO MESSAGE
========================================================= */

function notify(message, type = "info") {

    if (
        window.Tenko &&
        typeof window.Tenko[type] === "function"
    ) {

        window.Tenko[type](message);

        return;
    }


    if (
        window.Tenko &&
        typeof window.Tenko.info === "function"
    ) {

        window.Tenko.info(message);

        return;
    }


    console.info(
        `[TENKAI] ${message}`
    );

}


/* =========================================================
   SAFE HTML
========================================================= */

function escapeHTML(value) {

    const div =
        document.createElement("div");

    div.textContent =
        String(value ?? "");

    return div.innerHTML;

}


/* =========================================================
   FILTER DATA
========================================================= */

function getFilteredNotifications() {

    if (activeFilter === "all") {
        return notifications;
    }

    return notifications.filter(
        notification =>
            notification.type === activeFilter
    );

}


/* =========================================================
   UNREAD COUNT
========================================================= */

function getUnreadCount() {

    return notifications.filter(
        notification =>
            notification.unread
    ).length;

}


/* =========================================================
   UPDATE UNREAD UI
========================================================= */

function updateUnreadUI() {

    const unreadCount =
        getUnreadCount();


    /* Sidebar badge */

    if (sidebarBadge) {

        if (unreadCount > 0) {

            sidebarBadge.textContent =
                unreadCount > 99
                    ? "99+"
                    : unreadCount;

            sidebarBadge.hidden =
                false;

        } else {

            sidebarBadge.hidden =
                true;

        }

    }


    /* Topbar notification dot */

    if (notificationDot) {

        notificationDot.hidden =
            unreadCount === 0;

    }


    /* Mark all button */

    if (markAllButton) {

        markAllButton.disabled =
            unreadCount === 0;

        markAllButton.textContent =
            unreadCount === 0
                ? "All caught up"
                : "Mark all as read";

    }

}


/* =========================================================
   CREATE NOTIFICATION CARD
========================================================= */

function createNotificationCard(notification) {

    const card =
        document.createElement("article");

    card.className =
        `notification-card ${
            notification.unread
                ? "unread"
                : ""
        }`;

    card.dataset.id =
        notification.id;

    card.dataset.type =
        notification.type;


    card.innerHTML = `

        <div class="notification-avatar">

            ${escapeHTML(notification.avatar)}

            <span class="notification-type">

                ${
                    notificationIcons[
                        notification.type
                    ] || ""
                }

            </span>

        </div>


        <div class="notification-content">

            <div class="notification-message">

                <strong>
                    ${escapeHTML(notification.user)}
                </strong>

                ${notification.message}

            </div>


            <div class="notification-time">
                ${escapeHTML(notification.time)}
            </div>

        </div>


        <span
            class="unread-indicator"
            aria-hidden="true"
        ></span>

    `;


    card.addEventListener(
        "click",
        () => {

            handleNotificationClick(
                notification
            );

        }
    );


    return card;

}


/* =========================================================
   RENDER
========================================================= */

function renderNotifications() {

    if (!notificationList) {
        return;
    }


    const filtered =
        getFilteredNotifications();


    notificationList.innerHTML =
        "";


    if (filtered.length === 0) {

        notificationList.hidden =
            true;

        if (emptyState) {
            emptyState.hidden =
                false;
        }

        return;
    }


    notificationList.hidden =
        false;


    if (emptyState) {
        emptyState.hidden =
            true;
    }


    filtered.forEach(
        notification => {

            notificationList.appendChild(
                createNotificationCard(
                    notification
                )
            );

        }
    );

}


/* =========================================================
   NOTIFICATION CLICK
========================================================= */

function handleNotificationClick(
    notification
) {

    const target =
        notifications.find(
            item =>
                item.id === notification.id
        );


    if (!target) {
        return;
    }


    target.unread =
        false;


    renderNotifications();

    updateUnreadUI();


    /*
        FUTURE FIREBASE ROUTING

        likes:
            -> Post

        comments:
            -> Post / Comment

        follows:
            -> User Profile

        anime:
            -> Anime / Community

        This will be connected later.
    */

}


/* =========================================================
   MARK ALL AS READ
========================================================= */

function markAllAsRead() {

    notifications.forEach(
        notification => {

            notification.unread =
                false;

        }
    );


    renderNotifications();

    updateUnreadUI();


    notify(
        "All notifications marked as read.",
        "success"
    );

}


/* =========================================================
   FILTERS
========================================================= */

function setupFilters() {

    filterButtons.forEach(
        button => {

            button.addEventListener(
                "click",
                () => {

                    const filter =
                        button.dataset.filter;


                    if (!filter) {
                        return;
                    }


                    activeFilter =
                        filter;


                    filterButtons.forEach(
                        item => {

                            item.classList.toggle(
                                "active",
                                item === button
                            );

                        }
                    );


                    renderNotifications();

                }
            );

        }
    );

}


/* =========================================================
   SIDEBAR
========================================================= */

function openSidebar() {

    if (!sidebar) {
        return;
    }


    sidebar.classList.add(
        "open"
    );


    if (sidebarOverlay) {

        sidebarOverlay.hidden =
            false;

    }


    if (menuButton) {

        menuButton.setAttribute(
            "aria-expanded",
            "true"
        );

    }

}


function closeSidebar() {

    if (!sidebar) {
        return;
    }


    sidebar.classList.remove(
        "open"
    );


    if (sidebarOverlay) {

        sidebarOverlay.hidden =
            true;

    }


    if (menuButton) {

        menuButton.setAttribute(
            "aria-expanded",
            "false"
        );

    }

}


function setupSidebar() {

    if (menuButton) {

        menuButton.addEventListener(
            "click",
            () => {

                const isOpen =
                    sidebar &&
                    sidebar.classList.contains(
                        "open"
                    );


                if (isOpen) {

                    closeSidebar();

                } else {

                    openSidebar();

                }

            }
        );

    }


    if (sidebarOverlay) {

        sidebarOverlay.addEventListener(
            "click",
            closeSidebar
        );

    }

}


/* =========================================================
   TOPBAR NOTIFICATION
========================================================= */

function setupNotificationButton() {

    if (!notificationButton) {
        return;
    }


    notificationButton.addEventListener(
        "click",
        () => {

            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });

        }
    );

}


/* =========================================================
   CREATE POST
========================================================= */

function setupCreatePost() {

    if (!bottomCreateButton) {
        return;
    }


    bottomCreateButton.addEventListener(
        "click",
        () => {

            notify(
                "Create Post will be connected when the posting system is ready.",
                "info"
            );

        }
    );

}


/* =========================================================
   KEYBOARD
========================================================= */

function setupKeyboard() {

    document.addEventListener(
        "keydown",
        event => {

            if (event.key === "Escape") {

                closeSidebar();

            }

        }
    );

}


/* =========================================================
   RESPONSIVE SIDEBAR
========================================================= */

function setupResponsiveSidebar() {

    window.addEventListener(
        "resize",
        () => {

            if (
                window.innerWidth >= 700
                &&
                sidebar &&
                sidebar.classList.contains(
                    "open"
                )
            ) {

                closeSidebar();

            }

        }
    );

}


/* =========================================================
   INIT
========================================================= */

function initNotifications() {

    renderNotifications();

    updateUnreadUI();

    setupFilters();

    setupSidebar();

    setupNotificationButton();

    setupCreatePost();

    setupKeyboard();

    setupResponsiveSidebar();


    if (sidebarOverlay) {
        sidebarOverlay.hidden =
            true;
    }


    if (menuButton) {

        menuButton.setAttribute(
            "aria-expanded",
            "false"
        );

    }

}


if (
    document.readyState === "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initNotifications
    );

} else {

    initNotifications();

}