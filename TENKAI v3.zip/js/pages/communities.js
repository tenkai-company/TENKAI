"use strict";


/* =========================================================
   COMMUNITY DATA
========================================================= */

const communities = [

    {
        id: "aot",
        name: "Attack on Titan",
        description: "Everything about Attack on Titan.",
        category: "anime",
        members: 12840,
        icon: "AOT",
        featured: true
    },

    {
        id: "one-piece",
        name: "One Piece",
        description: "Sailing through the world of One Piece.",
        category: "anime",
        members: 9420,
        icon: "OP",
        featured: true
    },

    {
        id: "naruto",
        name: "Naruto",
        description: "The shinobi community.",
        category: "anime",
        members: 8130,
        icon: "N",
        featured: true
    },

    {
        id: "jjk",
        name: "Jujutsu Kaisen",
        description: "Curses, sorcerers and Jujutsu Kaisen.",
        category: "anime",
        members: 7600,
        icon: "JJK",
        featured: false
    },

    {
        id: "death-note",
        name: "Death Note",
        description: "Discuss Kira, L and the world of Death Note.",
        category: "anime",
        members: 5210,
        icon: "DN",
        featured: false
    },

    {
        id: "demon-slayer",
        name: "Demon Slayer",
        description: "Kimetsu no Yaiba fans.",
        category: "anime",
        members: 6890,
        icon: "DS",
        featured: false
    },

    {
        id: "manga-zone",
        name: "Manga Zone",
        description: "Manga discussions, recommendations and news.",
        category: "manga",
        members: 4360,
        icon: "M",
        featured: false
    },

    {
        id: "gaming",
        name: "Anime Gaming",
        description: "Anime games and gaming discussions.",
        category: "gaming",
        members: 3980,
        icon: "G",
        featured: false
    },

    {
        id: "japanese",
        name: "Japanese Learning",
        description: "Learn Japanese together with other TENKAI users.",
        category: "japanese",
        members: 2740,
        icon: "JP",
        featured: false
    }

];


/* =========================================================
   STATE
========================================================= */

const communityState = {

    category: "all",

    search: "",

    joined: new Set(),

    communities: [...communities]

};


/* =========================================================
   DOM
========================================================= */

const elements = {

    sidebar:
        document.getElementById("sidebar"),

    menuButton:
        document.getElementById("menuButton"),

    sidebarOverlay:
        document.getElementById("sidebarOverlay"),

    communitySearch:
        document.getElementById("communitySearch"),

    clearSearch:
        document.getElementById("clearCommunitySearch"),

    filters:
        document.querySelectorAll(".filter-button"),

    featured:
        document.getElementById("featuredCommunities"),

    grid:
        document.getElementById("communitiesGrid"),

    emptyState:
        document.getElementById("emptyState"),

    count:
        document.getElementById("communityCount"),

    refresh:
        document.getElementById("refreshCommunities"),

    createButton:
        document.getElementById("createCommunityButton"),

    bottomCreateButton:
        document.getElementById("bottomCreateButton"),

    modal:
        document.getElementById("communityModal"),

    closeModal:
        document.getElementById("closeCommunityModal"),

    form:
        document.getElementById("communityForm"),

    communityName:
        document.getElementById("communityName"),

    communityDescription:
        document.getElementById("communityDescription"),

    communityCategory:
        document.getElementById("communityCategory")

};


/* =========================================================
   SIDEBAR
========================================================= */

function openSidebar() {

    if (!elements.sidebar) {
        return;
    }


    elements.sidebar.classList.add("open");


    elements.menuButton?.setAttribute(
        "aria-expanded",
        "true"
    );


    if (elements.sidebarOverlay) {

        elements.sidebarOverlay.hidden = false;

    }

}


function closeSidebar() {

    if (!elements.sidebar) {
        return;
    }


    elements.sidebar.classList.remove("open");


    elements.menuButton?.setAttribute(
        "aria-expanded",
        "false"
    );


    if (elements.sidebarOverlay) {

        elements.sidebarOverlay.hidden = true;

    }

}


elements.menuButton?.addEventListener(
    "click",
    () => {

        const isOpen =
            elements.sidebar.classList.contains("open");


        if (isOpen) {

            closeSidebar();

        } else {

            openSidebar();

        }

    }
);


elements.sidebarOverlay?.addEventListener(
    "click",
    closeSidebar
);


/* =========================================================
   FILTERING
========================================================= */

function getFilteredCommunities() {

    return communityState.communities.filter(
        community => {

            const matchesCategory =
                communityState.category === "all" ||
                community.category ===
                    communityState.category;


            const search =
                communityState.search
                    .trim()
                    .toLowerCase();


            const matchesSearch =
                !search ||
                community.name
                    .toLowerCase()
                    .includes(search) ||
                community.description
                    .toLowerCase()
                    .includes(search);


            return (
                matchesCategory &&
                matchesSearch
            );

        }
    );

}


/* =========================================================
   NUMBER FORMAT
========================================================= */

function formatMembers(number) {

    if (number >= 1000000) {

        return `${(number / 1000000)
            .toFixed(1)
            .replace(".0", "")}M`;

    }


    if (number >= 1000) {

        return `${(number / 1000)
            .toFixed(1)
            .replace(".0", "")}K`;

    }


    return String(number);

}


/* =========================================================
   COMMUNITY CARD
========================================================= */

function createCommunityCard(community) {

    const article =
        document.createElement("article");


    article.className =
        "community-card";


    article.dataset.communityId =
        community.id;


    const joined =
        communityState.joined.has(
            community.id
        );


    article.innerHTML = `

        <div class="community-icon">
            ${escapeHTML(community.icon)}
        </div>


        <div class="community-info">

            <h3>
                ${escapeHTML(community.name)}
            </h3>

            <p>
                ${escapeHTML(community.description)}
            </p>

            <span class="community-members">
                ${formatMembers(community.members)}
                members
            </span>

        </div>


        <button
            class="join-button ${joined ? "joined" : ""}"
            type="button"
            data-join="${community.id}"
        >
            ${joined ? "Joined" : "Join"}
        </button>

    `;


    return article;

}


/* =========================================================
   FEATURED CARD
========================================================= */

function createFeaturedCard(community) {

    const article =
        document.createElement("article");


    article.className =
        "featured-card";


    article.dataset.communityId =
        community.id;


    article.innerHTML = `

        <div class="featured-icon">
            ${escapeHTML(community.icon)}
        </div>


        <h3>
            ${escapeHTML(community.name)}
        </h3>


        <p>
            ${escapeHTML(community.description)}
        </p>


        <div class="community-meta">

            <span>
                ${formatMembers(community.members)}
                members
            </span>

            <span>•</span>

            <span>
                ${capitalize(community.category)}
            </span>

        </div>

    `;


    return article;

}


/* =========================================================
   RENDER FEATURED
========================================================= */

function renderFeatured() {

    if (!elements.featured) {
        return;
    }


    elements.featured.innerHTML = "";


    const featured =
        communityState.communities
            .filter(
                community =>
                    community.featured
            )
            .slice(0, 3);


    featured.forEach(
        community => {

            elements.featured.appendChild(
                createFeaturedCard(
                    community
                )
            );

        }
    );

}


/* =========================================================
   RENDER COMMUNITIES
========================================================= */

function renderCommunities() {

    if (!elements.grid) {
        return;
    }


    const filtered =
        getFilteredCommunities();


    elements.grid.innerHTML = "";


    filtered.forEach(
        community => {

            elements.grid.appendChild(
                createCommunityCard(
                    community
                )
            );

        }
    );


    const count =
        filtered.length;


    if (elements.count) {

        elements.count.textContent =
            `${count} ${
                count === 1
                    ? "community"
                    : "communities"
            }`;

    }


    if (elements.emptyState) {

        elements.emptyState.hidden =
            count !== 0;

    }

}


/* =========================================================
   RENDER EVERYTHING
========================================================= */

function renderAll() {

    renderFeatured();

    renderCommunities();

}


/* =========================================================
   CATEGORY FILTER
========================================================= */

elements.filters.forEach(
    button => {

        button.addEventListener(
            "click",
            () => {

                elements.filters.forEach(
                    item => {

                        item.classList.remove(
                            "active"
                        );

                    }
                );


                button.classList.add(
                    "active"
                );


                communityState.category =
                    button.dataset.category ||
                    "all";


                renderCommunities();

            }
        );

    }
);


/* =========================================================
   SEARCH
========================================================= */

elements.communitySearch?.addEventListener(
    "input",
    event => {

        communityState.search =
            event.target.value;


        renderCommunities();

    }
);


elements.clearSearch?.addEventListener(
    "click",
    () => {

        if (!elements.communitySearch) {
            return;
        }


        elements.communitySearch.value =
            "";


        communityState.search =
            "";


        elements.communitySearch.focus();


        renderCommunities();

    }
);


/* =========================================================
   JOIN COMMUNITY
========================================================= */

elements.grid?.addEventListener(
    "click",
    event => {

        const button =
            event.target.closest(
                "[data-join]"
            );


        if (!button) {
            return;
        }


        const communityId =
            button.dataset.join;


        if (!communityId) {
            return;
        }


        if (
            communityState.joined.has(
                communityId
            )
        ) {

            communityState.joined.delete(
                communityId
            );

        } else {

            communityState.joined.add(
                communityId
            );

        }


        renderCommunities();

    }
);


/* =========================================================
   FEATURED CLICK
========================================================= */

elements.featured?.addEventListener(
    "click",
    event => {

        const card =
            event.target.closest(
                "[data-community-id]"
            );


        if (!card) {
            return;
        }


        const id =
            card.dataset.communityId;


        const community =
            communityState.communities.find(
                item =>
                    item.id === id
            );


        if (!community) {
            return;
        }


        showCommunityMessage(
            community
        );

    }
);


/* =========================================================
   REFRESH
========================================================= */

elements.refresh?.addEventListener(
    "click",
    () => {

        const original =
            elements.refresh.textContent;


        elements.refresh.textContent =
            "Refreshing...";


        window.setTimeout(
            () => {

                renderAll();


                elements.refresh.textContent =
                    original;

            },
            450
        );

    }
);


/* =========================================================
   MODAL
========================================================= */

function openCommunityModal() {

    if (!elements.modal) {
        return;
    }


    elements.modal.hidden = false;


    document.body.style.overflow =
        "hidden";


    window.setTimeout(
        () => {

            elements.communityName?.focus();

        },
        50
    );

}


function closeCommunityModal() {

    if (!elements.modal) {
        return;
    }


    elements.modal.hidden = true;


    document.body.style.overflow =
        "";

}


elements.createButton?.addEventListener(
    "click",
    openCommunityModal
);


elements.bottomCreateButton?.addEventListener(
    "click",
    openCommunityModal
);


elements.closeModal?.addEventListener(
    "click",
    closeCommunityModal
);


elements.modal?.addEventListener(
    "click",
    event => {

        if (
            event.target.matches(
                "[data-close-modal]"
            )
        ) {

            closeCommunityModal();

        }

    }
);


/* =========================================================
   CREATE COMMUNITY
========================================================= */

elements.form?.addEventListener(
    "submit",
    event => {

        event.preventDefault();


        const name =
            elements.communityName.value.trim();


        const description =
            elements.communityDescription
                .value
                .trim();


        const category =
            elements.communityCategory.value;


        if (
            !name ||
            !description ||
            !category
        ) {

            return;

        }


        const id =
            `community-${Date.now()}`;


        const newCommunity = {

            id,

            name,

            description,

            category,

            members: 1,

            icon:
                createCommunityIcon(
                    name
                ),

            featured: false

        };


        communityState.communities.unshift(
            newCommunity
        );


        communityState.joined.add(
            id
        );


        elements.form.reset();


        closeCommunityModal();


        renderAll();


        showCommunityMessage(
            newCommunity,
            true
        );

    }
);


/* =========================================================
   REAL PAGE NAVIGATION
========================================================= */

function navigateTo(path) {

    window.location.href = path;

}


/*
 * These links already point to real TENKAI pages.
 * We intentionally do NOT intercept them with
 * the Coming Soon system.
 */


/* =========================================================
   COMING SOON
========================================================= */

document.addEventListener(
    "click",
    event => {

        const target =
            event.target.closest(
                "[data-coming-soon]"
            );


        if (!target) {
            return;
        }


        event.preventDefault();


        const feature =
            target.dataset.comingSoon;


        showComingSoon(
            feature
        );

    }
);


/* =========================================================
   TOPBAR NOTIFICATIONS
========================================================= */

document
    .getElementById("notificationButton")
    ?.addEventListener(
        "click",
        () => {

            navigateTo(
                "../notification/notification.html"
            );

        }
    );


/* =========================================================
   HELPERS
========================================================= */

function capitalize(value) {

    if (!value) {
        return "";
    }


    return (
        value.charAt(0).toUpperCase() +
        value.slice(1)
    );

}


function createCommunityIcon(name) {

    const words =
        name
            .trim()
            .split(/\s+/)
            .filter(Boolean);


    if (words.length >= 2) {

        return (
            words[0].charAt(0) +
            words[1].charAt(0)
        ).toUpperCase();

    }


    return name
        .slice(0, 3)
        .toUpperCase();

}


function escapeHTML(value) {

    return String(value)
        .replaceAll(
            "&",
            "&amp;"
        )
        .replaceAll(
            "<",
            "&lt;"
        )
        .replaceAll(
            ">",
            "&gt;"
        )
        .replaceAll(
            '"',
            "&quot;"
        )
        .replaceAll(
            "'",
            "&#039;"
        );

}


/* =========================================================
   TEMPORARY UI MESSAGES
   Firebase / real navigation will replace these later.
========================================================= */

function showComingSoon(feature) {

    if (
        window.Tenko &&
        typeof window.Tenko.toast ===
            "function"
    ) {

        window.Tenko.toast(
            `${feature} is coming soon.`
        );

        return;

    }


    alert(
        `${feature} is coming soon.`
    );

}


function showCommunityMessage(
    community,
    created = false
) {

    const message =
        created
            ? `${community.name} was created.`
            : `${community.name} selected.`;


    if (
        window.Tenko &&
        typeof window.Tenko.toast ===
            "function"
    ) {

        window.Tenko.toast(
            message
        );

        return;

    }


    console.log(message);

}


/* =========================================================
   KEYBOARD
========================================================= */

document.addEventListener(
    "keydown",
    event => {

        if (event.key !== "Escape") {
            return;
        }


        if (
            elements.modal &&
            !elements.modal.hidden
        ) {

            closeCommunityModal();

            return;

        }


        closeSidebar();

    }
);


/* =========================================================
   INITIALIZE
========================================================= */

function initializeCommunities() {

    renderAll();

}


if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initializeCommunities
    );

} else {

    initializeCommunities();

}