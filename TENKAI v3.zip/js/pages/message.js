/* =========================================================
   TENKAI — MESSAGES
   Local prototype
   Firebase will replace the data layer later.
========================================================= */

"use strict";


/* =========================================================
   MOCK DATA
========================================================= */

const conversations = [
    {
        id: "mika-001",
        name: "Mika",
        username: "@mika",
        avatar: "M",
        preview: "Hey! Did you watch the new episode?",
        time: "2m",
        unread: true,

        messages: [
            {
                id: "msg-001",
                sender: "them",
                text: "Hey! 👋",
                time: "7:42 PM"
            },
            {
                id: "msg-002",
                sender: "them",
                text: "Did you watch the new episode?",
                time: "7:43 PM"
            },
            {
                id: "msg-003",
                sender: "me",
                text: "Not yet 😭 I'm watching it tonight.",
                time: "7:44 PM"
            }
        ]
    },

    {
        id: "ren-001",
        name: "Ren",
        username: "@ren_01",
        avatar: "R",
        preview: "Let's talk about Jujutsu Kaisen.",
        time: "18m",
        unread: true,

        messages: [
            {
                id: "msg-004",
                sender: "them",
                text: "Let's talk about Jujutsu Kaisen.",
                time: "7:20 PM"
            },
            {
                id: "msg-005",
                sender: "me",
                text: "Sure! But no spoilers 😂",
                time: "7:21 PM"
            }
        ]
    },

    {
        id: "akira-001",
        name: "Akira",
        username: "@akira",
        avatar: "A",
        preview: "See you tomorrow!",
        time: "1h",
        unread: false,

        messages: [
            {
                id: "msg-006",
                sender: "them",
                text: "See you tomorrow!",
                time: "6:31 PM"
            },
            {
                id: "msg-007",
                sender: "me",
                text: "See you! 👋",
                time: "6:33 PM"
            }
        ]
    }
];


const availableUsers = [
    {
        name: "Mika",
        username: "@mika",
        avatar: "M"
    },

    {
        name: "Ren",
        username: "@ren_01",
        avatar: "R"
    },

    {
        name: "Akira",
        username: "@akira",
        avatar: "A"
    }
];


/* =========================================================
   DOM
========================================================= */

const messagesLayout =
    document.getElementById("messagesLayout");

const conversationList =
    document.getElementById("conversationList");

const conversationEmpty =
    document.getElementById("conversationEmpty");

const conversationCount =
    document.getElementById("conversationCount");

const messageStatus =
    document.getElementById("messageStatus");

const messageSearchInput =
    document.getElementById("messageSearchInput");

const clearMessageSearch =
    document.getElementById("clearMessageSearch");

const chatPlaceholder =
    document.getElementById("chatPlaceholder");

const activeChat =
    document.getElementById("activeChat");

const chatMessages =
    document.getElementById("chatMessages");

const chatAvatar =
    document.getElementById("chatAvatar");

const chatUserName =
    document.getElementById("chatUserName");

const chatUserHandle =
    document.getElementById("chatUserHandle");

const chatBackButton =
    document.getElementById("chatBackButton");

const messageComposer =
    document.getElementById("messageComposer");

const messageInput =
    document.getElementById("messageInput");

const newMessageButton =
    document.getElementById("newMessageButton");

const newMessageModal =
    document.getElementById("newMessageModal");

const closeNewMessage =
    document.getElementById("closeNewMessage");

const recipientSearch =
    document.getElementById("recipientSearch");

const recipientResults =
    document.getElementById("recipientResults");

const markAllReadButton =
    document.getElementById("markAllReadButton");

const attachButton =
    document.getElementById("attachButton");


/* =========================================================
   STATE
========================================================= */

let activeConversationId = null;

/*
    true when the browser history currently
    contains a TENKAI chat state.
*/
let chatHistoryStateActive = false;


/* =========================================================
   HELPERS
========================================================= */

function escapeHTML(value) {

    const div =
        document.createElement("div");

    div.textContent =
        value;

    return div.innerHTML;
}


function getConversationById(id) {

    return conversations.find(
        conversation =>
            conversation.id === id
    );
}


function getUnreadCount() {

    return conversations.filter(
        conversation =>
            conversation.unread
    ).length;
}


/* =========================================================
   RENDER CONVERSATIONS
========================================================= */

function renderConversations(
    list = conversations
) {

    if (!conversationList) {
        return;
    }

    conversationList.innerHTML = "";

    if (conversationCount) {

        conversationCount.textContent =
            `${list.length} ${
                list.length === 1
                    ? "conversation"
                    : "conversations"
            }`;
    }


    if (list.length === 0) {

        if (conversationEmpty) {
            conversationEmpty.hidden = false;
        }

        updateStatus();

        return;
    }


    if (conversationEmpty) {
        conversationEmpty.hidden = true;
    }


    list.forEach(conversation => {

        const button =
            document.createElement("button");


        button.type =
            "button";


        button.className =
            "conversation-item";


        if (
            conversation.id ===
            activeConversationId
        ) {

            button.classList.add(
                "active"
            );
        }


        if (conversation.unread) {

            button.classList.add(
                "unread"
            );
        }


        button.dataset.conversationId =
            conversation.id;


        button.innerHTML = `

            <div class="avatar avatar-placeholder">
                ${escapeHTML(
                    conversation.avatar
                )}
            </div>

            <div class="conversation-copy">

                <div class="conversation-top">

                    <strong class="conversation-name">
                        ${escapeHTML(
                            conversation.name
                        )}
                    </strong>

                    <span class="conversation-time">
                        ${escapeHTML(
                            conversation.time
                        )}
                    </span>

                </div>

                <div class="conversation-preview">
                    ${escapeHTML(
                        conversation.preview
                    )}
                </div>

            </div>

            ${
                conversation.unread
                    ? `
                        <span
                            class="unread-dot"
                            aria-label="Unread"
                        ></span>
                    `
                    : ""
            }

        `;


        button.addEventListener(
            "click",
            () => {
                openConversation(
                    conversation.id
                );
            }
        );


        conversationList.appendChild(
            button
        );
    });


    updateStatus();
}


/* =========================================================
   OPEN CONVERSATION
========================================================= */

function openConversation(
    id,
    fromHistory = false
) {

    const conversation =
        getConversationById(id);


    if (!conversation) {
        return;
    }


    activeConversationId =
        id;


    /*
        Opening a conversation creates
        a browser-history state.

        Therefore mobile Back can return
        to the conversation list.
    */
    if (
        !fromHistory &&
        !chatHistoryStateActive
    ) {

        history.pushState(
            {
                tenkai: true,
                view: "chat",
                conversationId: id
            },
            "",
            `#chat-${encodeURIComponent(id)}`
        );


        chatHistoryStateActive =
            true;
    }


    /*
        Mark conversation as read
    */
    conversation.unread =
        false;


    /*
        Switch from placeholder
        to active chat.
    */
    if (chatPlaceholder) {
        chatPlaceholder.hidden =
            true;
    }


    if (activeChat) {
        activeChat.hidden =
            false;
    }


    /*
        Update chat header
    */
    if (chatAvatar) {

        chatAvatar.textContent =
            conversation.avatar;
    }


    if (chatUserName) {

        chatUserName.textContent =
            conversation.name;
    }


    if (chatUserHandle) {

        chatUserHandle.textContent =
            conversation.username;
    }


    /*
        Render messages
    */
    renderMessages(
        conversation
    );


    /*
        Re-render conversations
        so active state/unread state updates.
    */
    renderConversations(
        getFilteredConversations()
    );


    /*
        Mobile CSS state
    */
    if (messagesLayout) {

        messagesLayout.classList.add(
            "chat-open"
        );
    }


    /*
        Focus composer
    */
    requestAnimationFrame(() => {

        if (messageInput) {
            messageInput.focus();
        }
    });
}


/* =========================================================
   CLOSE CONVERSATION
========================================================= */

function closeConversation(
    useHistory = true
) {

    /*
        If we opened the chat through
        history.pushState(), go back one
        browser-history step.

        This is what makes the physical
        mobile Back button work correctly.
    */
    if (
        useHistory &&
        chatHistoryStateActive
    ) {

        history.back();

        return;
    }


    chatHistoryStateActive =
        false;


    activeConversationId =
        null;


    if (activeChat) {
        activeChat.hidden =
            true;
    }


    if (chatPlaceholder) {
        chatPlaceholder.hidden =
            false;
    }


    if (messagesLayout) {

        messagesLayout.classList.remove(
            "chat-open"
        );
    }


    renderConversations(
        getFilteredConversations()
    );
}


/* =========================================================
   RENDER CHAT MESSAGES
========================================================= */

function renderMessages(
    conversation
) {

    if (!chatMessages) {
        return;
    }


    chatMessages.innerHTML =
        "";


    const dateLabel =
        document.createElement("div");


    dateLabel.className =
        "chat-date";


    dateLabel.textContent =
        "Today";


    chatMessages.appendChild(
        dateLabel
    );


    conversation.messages.forEach(
        message => {

            const row =
                document.createElement(
                    "div"
                );


            row.className =
                "message-row";


            if (
                message.sender ===
                "me"
            ) {

                row.classList.add(
                    "mine"
                );

            } else {

                row.classList.add(
                    "theirs"
                );
            }


            const bubble =
                document.createElement(
                    "div"
                );


            bubble.className =
                "message-bubble";


            bubble.innerHTML = `

                <div class="message-text">
                    ${escapeHTML(
                        message.text
                    )}
                </div>

                <div class="message-meta">
                    ${escapeHTML(
                        message.time
                    )}
                </div>

            `;


            row.appendChild(
                bubble
            );


            chatMessages.appendChild(
                row
            );
        }
    );


    scrollChatToBottom();
}


/* =========================================================
   SCROLL CHAT TO BOTTOM
========================================================= */

function scrollChatToBottom() {

    if (!chatMessages) {
        return;
    }


    chatMessages.scrollTop =
        chatMessages.scrollHeight;
}


/* =========================================================
   SEND MESSAGE
========================================================= */

function sendMessage(
    text
) {

    const cleanText =
        text.trim();


    if (!cleanText) {
        return;
    }


    if (!activeConversationId) {
        return;
    }


    const conversation =
        getConversationById(
            activeConversationId
        );


    if (!conversation) {
        return;
    }


    const now =
        new Date();


    const time =
        now.toLocaleTimeString(
            [],
            {
                hour: "numeric",
                minute: "2-digit"
            }
        );


    conversation.messages.push({

        id:
            `local-${Date.now()}`,

        sender:
            "me",

        text:
            cleanText,

        time:
            time
    });


    conversation.preview =
        cleanText;


    conversation.time =
        "now";


    conversation.unread =
        false;


    if (messageInput) {
        messageInput.value =
            "";
    }


    renderMessages(
        conversation
    );


    renderConversations(
        getFilteredConversations()
    );


    setTimeout(() => {

        if (messageInput) {
            messageInput.focus();
        }

    }, 0);
}


/* =========================================================
   SEARCH CONVERSATIONS
========================================================= */

function getFilteredConversations() {

    if (!messageSearchInput) {
        return conversations;
    }


    const query =
        messageSearchInput.value
            .trim()
            .toLowerCase();


    if (!query) {
        return conversations;
    }


    return conversations.filter(
        conversation => {

            return (

                conversation.name
                    .toLowerCase()
                    .includes(query)

                ||

                conversation.username
                    .toLowerCase()
                    .includes(query)

                ||

                conversation.preview
                    .toLowerCase()
                    .includes(query)

            );
        }
    );
}


function filterConversations() {

    renderConversations(
        getFilteredConversations()
    );


    if (!messageSearchInput) {
        return;
    }


    const hasValue =
        messageSearchInput.value
            .trim()
            .length > 0;


    document
        .querySelector(
            ".message-search"
        )
        ?.classList.toggle(
            "has-value",
            hasValue
        );
}


/* =========================================================
   MESSAGE STATUS
========================================================= */

function updateStatus() {

    if (!messageStatus) {
        return;
    }


    const unread =
        getUnreadCount();


    if (unread === 0) {

        messageStatus.textContent =
            "All caught up";

        return;
    }


    messageStatus.textContent =
        `${unread} unread`;
}


/* =========================================================
   MARK ALL READ
========================================================= */

function markAllRead() {

    conversations.forEach(
        conversation => {

            conversation.unread =
                false;
        }
    );


    renderConversations(
        getFilteredConversations()
    );


    updateStatus();
}


/* =========================================================
   NEW MESSAGE MODAL
========================================================= */

function openNewMessageModal() {

    if (!newMessageModal) {
        return;
    }


    newMessageModal.hidden =
        false;


    if (recipientSearch) {

        recipientSearch.value =
            "";
    }


    renderRecipients(
        availableUsers
    );


    setTimeout(() => {

        if (recipientSearch) {
            recipientSearch.focus();
        }

    }, 50);
}


function closeNewMessageModal() {

    if (!newMessageModal) {
        return;
    }


    newMessageModal.hidden =
        true;


    if (recipientSearch) {

        recipientSearch.value =
            "";
    }
}


/* =========================================================
   RENDER RECIPIENTS
========================================================= */

function renderRecipients(
    users
) {

    if (!recipientResults) {
        return;
    }


    recipientResults.innerHTML =
        "";


    if (users.length === 0) {

        recipientResults.innerHTML = `

            <div class="conversation-empty">

                <strong>
                    No users found
                </strong>

                <span>
                    Try another username.
                </span>

            </div>

        `;

        return;
    }


    users.forEach(user => {

        const button =
            document.createElement(
                "button"
            );


        button.type =
            "button";


        button.className =
            "recipient-row";


        button.innerHTML = `

            <div class="avatar avatar-placeholder">
                ${escapeHTML(
                    user.avatar
                )}
            </div>

            <div>

                <strong>
                    ${escapeHTML(
                        user.name
                    )}
                </strong>

                <span>
                    ${escapeHTML(
                        user.username
                    )}
                </span>

            </div>

        `;


        button.addEventListener(
            "click",
            () => {

                startConversation(
                    user
                );
            }
        );


        recipientResults.appendChild(
            button
        );
    });
}


/* =========================================================
   START NEW CONVERSATION
========================================================= */

function startConversation(
    user
) {

    let conversation =
        conversations.find(
            item =>
                item.username ===
                user.username
        );


/*
        If conversation doesn't exist,
        create a local prototype conversation.
    */
    if (!conversation) {

        conversation = {

            id:
                `${user.name.toLowerCase()}-${Date.now()}`,

            name:
                user.name,

            username:
                user.username,

            avatar:
                user.avatar,

            preview:
                "Start a new conversation.",

            time:
                "now",

            unread:
                false,

            messages:
                []
        };


        conversations.unshift(
            conversation
        );
    }


    closeNewMessageModal();


    renderConversations(
        getFilteredConversations()
    );


    openConversation(
        conversation.id
    );
}


/* =========================================================
   RECIPIENT SEARCH
========================================================= */

function searchRecipients() {

    if (!recipientSearch) {
        return;
    }


    const query =
        recipientSearch.value
            .trim()
            .toLowerCase();


    if (!query) {

        renderRecipients(
            availableUsers
        );

        return;
    }


    const filtered =
        availableUsers.filter(
            user => {

                return (

                    user.name
                        .toLowerCase()
                        .includes(query)

                    ||

                    user.username
                        .toLowerCase()
                        .includes(query)

                );
            }
        );


    renderRecipients(
        filtered
    );
}


/* =========================================================
   EVENTS
========================================================= */


/*
    Send message
*/
messageComposer?.addEventListener(
    "submit",
    event => {

        event.preventDefault();


        sendMessage(
            messageInput.value
        );
    }
);


/*
    Search conversations
*/
messageSearchInput?.addEventListener(
    "input",
    filterConversations
);


/*
    Clear conversation search
*/
clearMessageSearch?.addEventListener(
    "click",
    () => {

        if (!messageSearchInput) {
            return;
        }


        messageSearchInput.value =
            "";


        filterConversations();


        messageSearchInput.focus();
    }
);


/*
    Back button inside chat
*/
chatBackButton?.addEventListener(
    "click",
    () => {

        closeConversation(
            true
        );
    }
);


/*
    New message
*/
newMessageButton?.addEventListener(
    "click",
    openNewMessageModal
);


/*
    Close new message modal
*/
closeNewMessage?.addEventListener(
    "click",
    closeNewMessageModal
);


/*
    Close modal by clicking overlay
*/
newMessageModal?.addEventListener(
    "click",
    event => {

        if (
            event.target ===
            newMessageModal
        ) {

            closeNewMessageModal();
        }
    }
);


/*
    Search recipients
*/
recipientSearch?.addEventListener(
    "input",
    searchRecipients
);


/*
    Mark all as read
*/
markAllReadButton?.addEventListener(
    "click",
    markAllRead
);


/*
    Attachment button
*/
attachButton?.addEventListener(
    "click",
    () => {

        if (
            typeof window.Tenko !==
                "undefined"
            &&
            typeof window.Tenko.toast ===
                "function"
        ) {

            window.Tenko.toast(
                "Media attachments will be available soon."
            );

        } else {

            alert(
                "Media attachments will be available soon."
            );
        }
    }
);


/* =========================================================
   ESCAPE KEY
========================================================= */

document.addEventListener(
    "keydown",
    event => {

        if (
            event.key !==
            "Escape"
        ) {
            return;
        }


        /*
            If modal is open,
            close it first.
        */
        if (
            newMessageModal &&
            !newMessageModal.hidden
        ) {

            closeNewMessageModal();

            return;
        }


        /*
            If chat is open,
            go back to conversations.
        */
        if (
            activeConversationId
        ) {

            closeConversation(
                true
            );
        }
    }
);


/* =========================================================
   INITIALIZE
========================================================= */

function initMessages() {

    /*
        Make the current page the
        base TENKAI messages state.
    */
    history.replaceState(
        {
            tenkai: true,
            view: "messages"
        },
        "",
        window.location.pathname +
        window.location.search
    );


    chatHistoryStateActive =
        false;


    activeConversationId =
        null;


    if (messagesLayout) {

        messagesLayout.classList.remove(
            "chat-open"
        );
    }


    if (activeChat) {
        activeChat.hidden =
            true;
    }


    if (chatPlaceholder) {
        chatPlaceholder.hidden =
            false;
    }


    renderConversations(
        conversations
    );


    updateStatus();
}


/* =========================================================
   MOBILE / BROWSER BACK
========================================================= */

window.addEventListener(
    "popstate",
    event => {

        /*
            If the new history state is
            a TENKAI chat state, restore
            that conversation.
        */
        if (
            event.state?.tenkai &&
            event.state.view ===
                "chat"
        ) {

            const conversation =
                getConversationById(
                    event.state
                        .conversationId
                );


            if (conversation) {

                chatHistoryStateActive =
                    true;


                openConversation(
                    conversation.id,
                    true
                );


                return;
            }
        }


        /*
            If we came back from the chat
            state, close the chat and show
            the conversation list.
        */
        if (
            activeConversationId ||
            chatHistoryStateActive
        ) {

            closeConversation(
                false
            );
        }
    }
);


/* =========================================================
   START
========================================================= */

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initMessages
    );

} else {

    initMessages();
}