/* =========================================================
   TENKAI — EXPLORE
========================================================= */

"use strict";


/* =========================================================
   DOM
========================================================= */

const menuButton = document.getElementById("menuButton");
const sidebar = document.getElementById("sidebar");
const sidebarOverlay = document.getElementById("sidebarOverlay");

const notificationButton =
    document.getElementById("notificationButton");

const mobileSearch =
    document.getElementById("mobileSearch");

const mobileSearchInput =
    document.getElementById("mobileSearchInput");

const clearMobileSearch =
    document.getElementById("clearMobileSearch");

const exploreSearch =
    document.getElementById("exploreSearch");

const clearExploreSearch =
    document.getElementById("clearExploreSearch");

const searchResultsSection =
    document.getElementById("searchResultsSection");

const searchResults =
    document.getElementById("searchResults");

const searchResultCount =
    document.getElementById("searchResultCount");

const exploreEmpty =
    document.getElementById("exploreEmpty");

const trendingSeeAll =
    document.getElementById("trendingSeeAll");

const communitiesSeeAll =
    document.getElementById("communitiesSeeAll");

const bottomCreateButton =
    document.getElementById("bottomCreateButton");


/* =========================================================
   DATA
========================================================= */

const exploreData = [

    {
        name: "Jujutsu Kaisen",
        type: "Anime",
        meta: "12.8K posts",
        short: "JJK"
    },

    {
        name: "One Piece",
        type: "Anime",
        meta: "9.4K posts",
        short: "OP"
    },

    {
        name: "Attack on Titan",
        type: "Anime",
        meta: "7.1K posts",
        short: "AOT"
    },

    {
        name: "Demon Slayer",
        type: "Anime",
        meta: "6.5K posts",
        short: "DS"
    },

    {
        name: "Naruto",
        type: "Anime",
        meta: "5.8K posts",
        short: "N"
    },

    {
        name: "Death Note",
        type: "Anime",
        meta: "4.9K posts",
        short: "DN"
    },

    {
        name: "My Hero Academia",
        type: "Anime",
        meta: "4.2K posts",
        short: "MHA"
    },

    {
        name: "Dragon Ball",
        type: "Anime",
        meta: "3.8K posts",
        short: "DB"
    },

    {
        name: "Mika",
        type: "User",
        meta: "@mika",
        short: "M"
    },

    {
        name: "Ren",
        type: "User",
        meta: "@ren_01",
        short: "R"
    },

    {
        name: "Akira",
        type: "User",
        meta: "@akira",
        short: "A"
    },

    {
        name: "One Piece",
        type: "Community",
        meta: "18.4K members",
        short: "OP"
    },

    {
        name: "Attack on Titan",
        type: "Community",
        meta: "14.2K members",
        short: "AOT"
    },

    {
        name: "Jujutsu Kaisen",
        type: "Community",
        meta: "11.7K members",
        short: "JJK"
    }

];


/* =========================================================
   SIDEBAR
========================================================= */

function openSidebar() {

    if (!sidebar) {
        return;
    }

    sidebar.classList.add("open");

    if (sidebarOverlay) {
        sidebarOverlay.hidden = false;
    }

    if (menuButton) {
        menuButton.setAttribute(
            "aria-expanded",
            "true"
        );
    }

}


function closeSidebar() {

    if (!sidebar) {
        return;
    }

    sidebar.classList.remove("open");

    if (sidebarOverlay) {
        sidebarOverlay.hidden = true;
    }

    if (menuButton) {
        menuButton.setAttribute(
            "aria-expanded",
            "false"
        );
    }

}


if (menuButton) {

    menuButton.addEventListener(
        "click",
        () => {

            const isOpen =
                sidebar.classList.contains("open");

            if (isOpen) {
                closeSidebar();
            } else {
                openSidebar();
            }

        }
    );

}


if (sidebarOverlay) {

    sidebarOverlay.addEventListener(
        "click",
        closeSidebar
    );

}


/* =========================================================
   MOBILE SEARCH
========================================================= */

function openMobileSearch() {

    if (!mobileSearch) {
        return;
    }

    mobileSearch.hidden = false;

    if (mobileSearchInput) {
        mobileSearchInput.focus();
    }

}


function closeMobileSearch() {

    if (!mobileSearch) {
        return;
    }

    mobileSearch.hidden = true;

}


function clearMobileSearchInput() {

    if (!mobileSearchInput) {
        return;
    }

    mobileSearchInput.value = "";

    mobileSearchInput.focus();

}


if (clearMobileSearch) {

    clearMobileSearch.addEventListener(
        "click",
        clearMobileSearchInput
    );

}


/* =========================================================
   SEARCH
========================================================= */

function normalize(value) {

    return String(value || "")
        .trim()
        .toLowerCase();

}


function createSearchResult(item) {

    const button =
        document.createElement("button");

    button.type = "button";

    button.className =
        "search-result";

    button.dataset.name =
        item.name;

    button.dataset.type =
        item.type;


    const icon =
        document.createElement("span");

    icon.className =
        "search-result-icon";

    icon.textContent =
        item.short;


    const copy =
        document.createElement("span");

    copy.className =
        "search-result-copy";


    const name =
        document.createElement("strong");

    name.textContent =
        item.name;


    const meta =
        document.createElement("span");

    meta.textContent =
        item.meta;


    copy.appendChild(name);
    copy.appendChild(meta);


    const type =
        document.createElement("span");

    type.className =
        "search-result-type";

    type.textContent =
        item.type;


    button.appendChild(icon);
    button.appendChild(copy);
    button.appendChild(type);


    button.addEventListener(
        "click",
        () => {

            handleResultClick(item);

        }
    );


    return button;

}


function handleResultClick(item) {

    if (window.Tenko && typeof window.Tenko.toast === "function") {

        window.Tenko.toast(
            `${item.name} — ${item.type}`
        );

        return;

    }

    alert(
        `${item.name} — ${item.type}`
    );

}


function performSearch(value) {

    const query =
        normalize(value);


    if (!searchResultsSection) {
        return;
    }


    if (!query) {

        searchResultsSection.hidden = true;

        if (exploreEmpty) {
            exploreEmpty.hidden = true;
        }

        if (searchResults) {
            searchResults.innerHTML = "";
        }

        return;

    }


    const results =
        exploreData.filter(
            item =>
                normalize(item.name)
                    .includes(query)
                ||
                normalize(item.type)
                    .includes(query)
                ||
                normalize(item.meta)
                    .includes(query)
        );


    if (searchResults) {

        searchResults.innerHTML = "";

        results.forEach(
            item => {

                searchResults.appendChild(
                    createSearchResult(item)
                );

            }
        );

    }


    searchResultsSection.hidden = false;


    if (searchResultCount) {

        searchResultCount.textContent =
            `${results.length} result${results.length === 1 ? "" : "s"}`;

    }


    if (exploreEmpty) {

        exploreEmpty.hidden =
            results.length !== 0;

    }

}


if (exploreSearch) {

    exploreSearch.addEventListener(
        "input",
        event => {

            performSearch(
                event.target.value
            );

        }
    );

}


if (clearExploreSearch) {

    clearExploreSearch.addEventListener(
        "click",
        () => {

            if (exploreSearch) {

                exploreSearch.value = "";

                performSearch("");

                exploreSearch.focus();

            }

        }
    );

}


if (mobileSearchInput) {

    mobileSearchInput.addEventListener(
        "input",
        event => {

            const value =
                event.target.value;

            if (exploreSearch) {
                exploreSearch.value = value;
            }

            performSearch(value);

        }
    );

}


/* =========================================================
   ANIME / COMMUNITY BUTTONS
========================================================= */

document
    .querySelectorAll("[data-anime]")
    .forEach(
        button => {

            button.addEventListener(
                "click",
                () => {

                    const anime =
                        button.dataset.anime;

                    if (exploreSearch) {

                        exploreSearch.value =
                            anime;

                        performSearch(anime);

                        exploreSearch.scrollIntoView({
                            behavior: "smooth",
                            block: "center"
                        });

                    }

                }
            );

        }
    );


document
    .querySelectorAll("[data-community]")
    .forEach(
        button => {

            button.addEventListener(
                "click",
                () => {

                    const community =
                        button.dataset.community;

                    if (window.Tenko && typeof window.Tenko.toast === "function") {

                        window.Tenko.toast(
                            `${community} community coming soon`
                        );

                    } else {

                        alert(
                            `${community} community coming soon`
                        );

                    }

                }
            );

        }
    );


/* =========================================================
   FOLLOW
========================================================= */

document
    .querySelectorAll("[data-follow-user]")
    .forEach(
        button => {

            button.addEventListener(
                "click",
                event => {

                    event.stopPropagation();

                    const user =
                        button.dataset.followUser;

                    const following =
                        button.classList.toggle(
                            "following"
                        );


                    button.textContent =
                        following
                            ? "Following"
                            : "Follow";


                    if (window.Tenko && typeof window.Tenko.toast === "function") {

                        window.Tenko.toast(
                            following
                                ? `Following ${user}`
                                : `Unfollowed ${user}`
                        );

                    }

                }
            );

        }
    );


/* =========================================================
   TOP ACTIONS
========================================================= */

if (notificationButton) {

    notificationButton.addEventListener(
        "click",
        () => {
            window.location.href = "notification/notification.html";
        }
    );

}


if (trendingSeeAll) {

    trendingSeeAll.addEventListener(
        "click",
        () => {

            if (exploreSearch) {

                exploreSearch.value =
                    "";

                performSearch("");

                exploreSearch.focus();

            }

        }
    );

}


if (communitiesSeeAll) {

    communitiesSeeAll.addEventListener(
        "click",
        () => {

            if (window.Tenko && typeof window.Tenko.toast === "function") {

                window.Tenko.toast(
                    "More communities coming soon"
                );

            } else {

                alert(
                    "More communities coming soon"
                );

            }

        }
    );

}


if (bottomCreateButton) {

    bottomCreateButton.addEventListener(
        "click",
        () => {

            if (window.Tenko && typeof window.Tenko.toast === "function") {

                window.Tenko.toast(
                    "Create Post coming soon"
                );

            } else {

                alert(
                    "Create Post coming soon"
                );

            }

        }
    );

}


/* =========================================================
   COMING SOON
========================================================= */

document
    .querySelectorAll("[data-coming-soon]")
    .forEach(
        element => {

            element.addEventListener(
                "click",
                event => {

                    event.preventDefault();

                    const feature =
                        element.dataset.comingSoon;

                    if (window.Tenko && typeof window.Tenko.toast === "function") {

                        window.Tenko.toast(
                            `${feature} coming soon`
                        );

                    } else {

                        alert(
                            `${feature} coming soon`
                        );

                    }

                }
            );

        }
    );


/* =========================================================
   RESPONSIVE SIDEBAR
========================================================= */

window.addEventListener(
    "resize",
    () => {

        if (
            window.innerWidth >= 700
            &&
            sidebar
            &&
            sidebar.classList.contains("open")
        ) {

            closeSidebar();

        }

    }
);


/* =========================================================
   ESCAPE KEY
========================================================= */

document.addEventListener(
    "keydown",
    event => {

        if (event.key !== "Escape") {
            return;
        }

        closeSidebar();

        closeMobileSearch();

        if (exploreSearch) {

            exploreSearch.blur();

        }

    }
);


/* =========================================================
   INIT
========================================================= */

function initExplore() {

    if (searchResultsSection) {
        searchResultsSection.hidden = true;
    }

    if (exploreEmpty) {
        exploreEmpty.hidden = true;
    }

    closeSidebar();

}


if (
    document.readyState === "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initExplore
    );

} else {

    initExplore();

}