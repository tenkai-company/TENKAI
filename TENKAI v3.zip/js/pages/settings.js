/* =========================================================
   TENKAI — SETTINGS
========================================================= */

"use strict";


document.addEventListener("DOMContentLoaded", () => {

    const backButton =
        document.getElementById("backButton");

    const spoilerToggle =
        document.getElementById("spoilerToggle");

    const logoutButton =
        document.getElementById("logoutButton");

    const createButton =
        document.getElementById("createButton");


    const settingItems =
        document.querySelectorAll(
            ".settings-item[data-setting]"
        );


    /* =====================================================
       BACK
    ===================================================== */

    if (backButton) {

        backButton.addEventListener("click", () => {

            if (window.history.length > 1) {

                window.history.back();

            } else {

                window.location.href =
                    "../home/home.html";

            }

        });

    }


    /* =====================================================
       SPOILER PROTECTION
    ===================================================== */

    let spoilerEnabled =
        localStorage.getItem(
            "tenkai_spoiler_protection"
        );


    if (spoilerEnabled === null) {

        spoilerEnabled = true;

        localStorage.setItem(
            "tenkai_spoiler_protection",
            "true"
        );

    } else {

        spoilerEnabled =
            spoilerEnabled === "true";

    }


    function updateSpoilerToggle() {

        if (!spoilerToggle) {
            return;
        }


        spoilerToggle.classList.toggle(
            "active",
            spoilerEnabled
        );


        spoilerToggle.setAttribute(
            "aria-checked",
            String(spoilerEnabled)
        );

    }


    updateSpoilerToggle();


    const spoilerSetting =
        document.querySelector(
            '[data-setting="spoilers"]'
        );


    if (spoilerSetting) {

        spoilerSetting.addEventListener(
            "click",
            () => {

                spoilerEnabled =
                    !spoilerEnabled;


                localStorage.setItem(
                    "tenkai_spoiler_protection",
                    String(spoilerEnabled)
                );


                updateSpoilerToggle();

            }
        );

    }


    /* =====================================================
       SETTINGS ACTIONS
    ===================================================== */

    settingItems.forEach((item) => {

        item.addEventListener(
            "click",
            () => {

                const setting =
                    item.dataset.setting;


                if (!setting) {
                    return;
                }


                /*
                 * Spoiler Protection has
                 * its own handler above.
                 */

                if (setting === "spoilers") {
                    return;
                }


                handleSetting(setting);

            }
        );

    });


    function handleSetting(setting) {

        switch (setting) {

            case "account":

                showTenkoMessage(
                    "Account settings are coming soon."
                );

                break;


            case "password":

                showTenkoMessage(
                    "Password & security will be available soon."
                );

                break;


            case "appearance":

                showTenkoMessage(
                    "Dark mode is currently enabled."
                );

                break;


            case "language":

                showTenkoMessage(
                    "Language selection is coming soon."
                );

                break;


            case "notifications":

                showTenkoMessage(
                    "Notification settings are coming soon."
                );

                break;


            case "privacy":

                showTenkoMessage(
                    "Privacy controls are coming soon."
                );

                break;


            case "help":

                showTenkoMessage(
                    "The TENKAI Help Center is coming soon."
                );

                break;


            case "about":

                showTenkoMessage(
                    "TENKAI v1.0"
                );

                break;


            default:

                showTenkoMessage(
                    "This setting is coming soon."
                );

        }

    }


    /* =====================================================
       CREATE
    ===================================================== */

    if (createButton) {

        createButton.addEventListener(
            "click",
            () => {

                showTenkoMessage(
                    "Create is coming soon."
                );

            }
        );

    }


    /* =====================================================
       LOGOUT
    ===================================================== */

    if (logoutButton) {

        logoutButton.addEventListener(
            "click",
            () => {

                const confirmed =
                    window.confirm(
                        "Are you sure you want to log out?"
                    );


                if (!confirmed) {
                    return;
                }


                /*
                 * Firebase logout will be connected
                 * here in the final Firebase phase.
                 */


                localStorage.removeItem(
                    "tenkai_user_session"
                );


                showTenkoMessage(
                    "You have been logged out."
                );


                setTimeout(() => {

                    window.location.href =
                        "../../pages/auth/login.html";

                }, 900);

            }
        );

    }


    /* =====================================================
       TENKO MESSAGE
    ===================================================== */

    function showTenkoMessage(message) {

        if (
            typeof window.Tenko !== "undefined" &&
            typeof window.Tenko.showMessage === "function"
        ) {

            window.Tenko.showMessage(message);

            return;

        }


        /*
         * Temporary fallback until Tenko
         * exposes its message API.
         */

        console.info(
            "TENKAI:",
            message
        );

    }

});