/* =========================================================
   TENKAI — TENKO
   Global Message System
========================================================= */

"use strict";


/* =========================================================
   STATE
========================================================= */

let tenkoTimer = null;


/* =========================================================
   CONFIG
========================================================= */

const TENKO_CONFIG = {

    duration: 3500,

    avatar:
        "../../assets/images/tenko.png"

};


/* =========================================================
   CREATE TENKO
========================================================= */

function createTenko() {

    let box =
        document.getElementById(
            "tenkoMessage"
        );


    if (box) {

        return box;

    }


    box =
        document.createElement(
            "div"
        );


    box.id =
        "tenkoMessage";


    box.setAttribute(
        "role",
        "status"
    );


    box.setAttribute(
        "aria-live",
        "polite"
    );


    box.innerHTML = `

        <img
            class="tenkoAvatar"
            src="${TENKO_CONFIG.avatar}"
            alt="Tenko"
        >

        <div class="tenkoBody">

            <div class="tenkoHeader">

                <span class="tenkoName">
                    Tenko
                </span>

                <span class="tenkoTime">
                    Now
                </span>

            </div>

            <div class="tenkoText"></div>

        </div>

        <button
            class="tenkoClose"
            type="button"
            aria-label="Close"
        >
            ×
        </button>

    `;


    document.body.appendChild(
        box
    );


    const closeButton =
        box.querySelector(
            ".tenkoClose"
        );


    if (closeButton) {

        closeButton.addEventListener(
            "click",
            hideTenko
        );

    }


    return box;

}


/* =========================================================
   SHOW TENKO
========================================================= */

function tenkoMessage(
    message,
    type = "info",
    duration = TENKO_CONFIG.duration
) {

    const box =
        createTenko();


    if (!box) {

        return;

    }


    const text =
        box.querySelector(
            ".tenkoText"
        );


    if (!text) {

        return;

    }


    const validTypes = [

        "info",
        "success",
        "warning",
        "error"

    ];


    if (
        !validTypes.includes(type)
    ) {

        type = "info";

    }


    /* =========================
       RESET TYPE
    ========================= */

    box.classList.remove(

        "info",
        "success",
        "warning",
        "error"

    );


    box.classList.add(
        type
    );


    /* =========================
       MESSAGE
    ========================= */

    text.textContent =
        message;


    /* =========================
       CLEAR OLD TIMER
    ========================= */

    if (tenkoTimer) {

        clearTimeout(
            tenkoTimer
        );

        tenkoTimer = null;

    }


    /* =========================
       RESTART ANIMATION
    ========================= */

    box.classList.remove(
        "show"
    );


    requestAnimationFrame(
        () => {

            requestAnimationFrame(
                () => {

                    box.classList.add(
                        "show"
                    );

                }
            );

        }
    );


    /* =========================
       AUTO HIDE
    ========================= */

    if (
        duration > 0
    ) {

        tenkoTimer =
            setTimeout(
                () => {

                    hideTenko();

                },
                duration
            );

    }

}


/* =========================================================
   HIDE TENKO
========================================================= */

function hideTenko() {

    const box =
        document.getElementById(
            "tenkoMessage"
        );


    if (!box) {

        return;

    }


    box.classList.remove(
        "show"
    );


    if (tenkoTimer) {

        clearTimeout(
            tenkoTimer
        );

        tenkoTimer = null;

    }

}


/* =========================================================
   INFO
========================================================= */

function tenkoInfo(
    message,
    duration
) {

    tenkoMessage(
        message,
        "info",
        duration
    );

}


/* =========================================================
   SUCCESS
========================================================= */

function tenkoSuccess(
    message,
    duration
) {

    tenkoMessage(
        message,
        "success",
        duration
    );

}


/* =========================================================
   WARNING
========================================================= */

function tenkoWarning(
    message,
    duration
) {

    tenkoMessage(
        message,
        "warning",
        duration
    );

}


/* =========================================================
   ERROR
========================================================= */

function tenkoError(
    message,
    duration
) {

    tenkoMessage(
        message,
        "error",
        duration
    );

}


/* =========================================================
   GLOBAL API
========================================================= */

window.tenkoMessage =
    tenkoMessage;


window.tenkoInfo =
    tenkoInfo;


window.tenkoSuccess =
    tenkoSuccess;


window.tenkoWarning =
    tenkoWarning;


window.tenkoError =
    tenkoError;


window.hideTenko =
    hideTenko;


/* =========================================================
   READY
========================================================= */

console.log(
    "TENKO Message System is running."
);